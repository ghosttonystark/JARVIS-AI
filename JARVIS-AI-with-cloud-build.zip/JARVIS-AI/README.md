# JARVIS AI — Android assistant (Kotlin + Jetpack Compose)

Futuristic HUD assistant: animated JARVIS core, voice in/out, pluggable AI brain,
local memory, safe Android commands. Builds from Termux. **Zero third-party deps** beyond AndroidX/Compose.

## Architecture
```
com.jarvis.ai
├── JarvisApp / MainActivity
├── ai/        AIService (interface) → GeminiProvider, OpenAIProvider, ClaudeProvider, LocalProvider
│              Http (HttpURLConnection), JarvisPrompt (system prompt)
├── voice/     VoiceManager (TTS, female-voice heuristic + fallback), SpeechInput (SpeechRecognizer)
├── memory/    MemoryRepository          database/  JarvisDb (SQLite: messages, memories)
├── commands/  CommandManager → Utility / Device / System / Media / App command groups
├── settings/  Settings + SettingsStore, SecureKeyStore (Android Keystore AES-GCM for API keys)
└── ui/        Theme (HUD look), JarvisCore (animated rings), HomeScreen, Screens, SettingsScreens,
               Onboarding + drawer (JarvisRoot), JarvisViewModel
```
Why SQLiteOpenHelper instead of Room: Room needs KSP, which is slow/memory-hungry on a phone.

## 1. Termux setup (once)
```bash
pkg update && pkg upgrade -y
pkg install -y openjdk-17 wget unzip git aapt2
termux-setup-storage

# Android SDK (command-line tools)
mkdir -p ~/android-sdk/cmdline-tools && cd ~/android-sdk/cmdline-tools
wget https://dl.google.com/android/repository/commandlinetools-linux-11076708_latest.zip
unzip commandlinetools-linux-*.zip && mv cmdline-tools latest && cd ~

cat >> ~/.bashrc <<'RC'
export JAVA_HOME=$PREFIX/lib/jvm/java-17-openjdk
export ANDROID_HOME=$HOME/android-sdk
export ANDROID_SDK_ROOT=$ANDROID_HOME
export PATH=$PATH:$ANDROID_HOME/cmdline-tools/latest/bin
RC
source ~/.bashrc

yes | sdkmanager --licenses
sdkmanager "platforms;android-34" "build-tools;34.0.0"

# The SDK's aapt2 is an x86 binary; make Gradle use Termux's aapt2 instead
mkdir -p ~/.gradle
echo "android.aapt2FromMavenOverride=$PREFIX/bin/aapt2" >> ~/.gradle/gradle.properties
```

## 2. Gradle (needs 8.7 – 8.x for AGP 8.5.2)
```bash
cd ~ && wget https://services.gradle.org/distributions/gradle-8.9-bin.zip
unzip gradle-8.9-bin.zip -d ~/gradle
echo 'export PATH=$PATH:$HOME/gradle/gradle-8.9/bin' >> ~/.bashrc && source ~/.bashrc
gradle -v
```

## 3. Build
```bash
cd ~/JARVIS-AI
echo "sdk.dir=$ANDROID_HOME" > local.properties
gradle wrapper --gradle-version 8.9        # creates ./gradlew (once)
./gradlew assembleDebug                    # first build downloads a lot; be patient
# APK: app/build/outputs/apk/debug/app-debug.apk
```
Release (optional signing):
```bash
keytool -genkeypair -v -keystore jarvis-release.jks -alias jarvis -keyalg RSA -keysize 2048 -validity 10000
export JARVIS_KS_PASS='your-password'      # same for store + key
./gradlew assembleRelease                  # app/build/outputs/apk/release/app-release.apk
```
Without the keystore, release is signed with the debug key (fine for sideloading).

## 4. Install
```bash
termux-open app/build/outputs/apk/debug/app-debug.apk     # opens Android's installer
# or: cp it to ~/storage/downloads/ and tap it in your file manager
```
Allow "install unknown apps" for Termux when asked.

## 5. First run
Follow the wizard (mic → notifications → AI key → language → voice → tests).
Gemini has a free tier; get a key at aistudio.google.com. Model names change over time —
edit the MODEL field in Settings if a provider retires one.

Local AI (offline): run an OpenAI-compatible server such as Ollama in Termux, choose
"Local server", URL `http://127.0.0.1:11434/v1`.

## Troubleshooting
- `aapt2` / "Daemon startup failed" → check the `aapt2FromMavenOverride` line and that `aapt2 version` works.
- Out of memory → lower `org.gradle.jvmargs` to `-Xmx1g`, close other apps, run `./gradlew --no-daemon assembleDebug`.
- "SDK location not found" → recreate `local.properties`.
- `Unsupported Gradle` → use Gradle 8.9 (not 9.x) with this AGP version.
- No speech recognition → install/enable Google (or another) speech service; some languages need internet.
- Voice sounds male / language silent → Settings → Voice → pick another voice; install voice data in Android's Text-to-speech settings.
- Mic denied permanently → Settings → Security → Manage permissions.

## Safety model
Commands are matched locally (not executed from AI text). Protected toggles (Wi-Fi, Bluetooth, location)
open the matching Android panel instead of bypassing security. Memory saves only on explicit "remember …".
