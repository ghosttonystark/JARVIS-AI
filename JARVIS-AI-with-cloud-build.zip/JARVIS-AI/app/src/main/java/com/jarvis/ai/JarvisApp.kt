package com.jarvis.ai

import android.app.Application
import com.jarvis.ai.database.JarvisDb
import com.jarvis.ai.memory.MemoryRepository
import com.jarvis.ai.settings.SecureKeyStore
import com.jarvis.ai.settings.SettingsStore

class JarvisApp : Application() {
    lateinit var keys: SecureKeyStore
    lateinit var settings: SettingsStore
    lateinit var db: JarvisDb
    lateinit var memory: MemoryRepository

    override fun onCreate() {
        super.onCreate()
        keys = SecureKeyStore(this)
        settings = SettingsStore(this, keys)
        db = JarvisDb(this)
        memory = MemoryRepository(db)
    }
}
