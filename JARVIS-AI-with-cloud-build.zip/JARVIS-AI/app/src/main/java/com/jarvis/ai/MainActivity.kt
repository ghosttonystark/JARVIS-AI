package com.jarvis.ai

import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.jarvis.ai.ui.JarvisRoot
import com.jarvis.ai.ui.JarvisTheme
import com.jarvis.ai.ui.JarvisViewModel

class MainActivity : ComponentActivity() {
    private val vm: JarvisViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(Color.TRANSPARENT)
        )
        setContent { JarvisTheme { JarvisRoot(vm) } }
    }

    override fun onStop() {
        super.onStop()
        vm.onBackground()
    }
}
