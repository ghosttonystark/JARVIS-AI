package com.jarvis.ai.ai

import org.json.JSONArray
import org.json.JSONObject

data class Turn(val role: String, val content: String) // role: "user" | "assistant"

data class AIConfig(
    val apiKey: String,
    val model: String,
    val temperature: Float,
    val maxTokens: Int,
    val baseUrl: String
)

class AIException(val kind: Kind, message: String) : Exception(message) {
    enum class Kind { NO_KEY, NETWORK, AUTH, RATE, SERVER, OTHER }
}

/** Implement this to plug in any provider. Register it in [AIFactory]. */
interface AIService {
    val id: String
    val displayName: String
    val defaultModel: String
    val suggestedModels: List<String>
    val needsKey: Boolean
    val needsInternet: Boolean
    suspend fun chat(system: String, history: List<Turn>, cfg: AIConfig): String
}

object AIFactory {
    val all: List<AIService> = listOf(GeminiProvider, OpenAIProvider, ClaudeProvider, LocalProvider)
    fun get(id: String): AIService = all.firstOrNull { it.id == id } ?: GeminiProvider
}

/** Providers require strictly alternating roles starting with "user". */
fun List<Turn>.normalized(): List<Turn> {
    val out = ArrayList<Turn>()
    for (t in this) {
        if (t.content.isBlank()) continue
        if (out.isEmpty() && t.role != "user") continue
        if (out.isNotEmpty() && out.last().role == t.role) {
            out[out.size - 1] = Turn(t.role, out.last().content + "\n" + t.content)
        } else out.add(t)
    }
    return out
}

internal fun requireKey(cfg: AIConfig, provider: String) {
    if (cfg.apiKey.isBlank()) throw AIException(AIException.Kind.NO_KEY, "Missing API key for $provider")
}

internal fun emptyReply(): Nothing =
    throw AIException(AIException.Kind.OTHER, "The AI returned an empty reply. Try raising “Max response length” in Settings.")

internal suspend fun openAiCompat(url: String, key: String, system: String, history: List<Turn>, cfg: AIConfig, tokenField: String): String {
    val msgs = JSONArray().put(JSONObject().put("role", "system").put("content", system))
    history.normalized().forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
    val body = JSONObject()
        .put("model", cfg.model)
        .put("messages", msgs)
        .put("temperature", cfg.temperature.toDouble())
        .put(tokenField, cfg.maxTokens)
    val headers = if (key.isNotBlank()) mapOf("Authorization" to "Bearer $key") else emptyMap()
    val r = Http.postJson(url, headers, body)
    val text = r.getJSONArray("choices").getJSONObject(0).getJSONObject("message").optString("content", "").trim()
    if (text.isEmpty() || text == "null") emptyReply()
    return text
}

object OpenAIProvider : AIService {
    override val id = "openai"
    override val displayName = "OpenAI"
    override val defaultModel = "gpt-4o-mini"
    override val suggestedModels = listOf("gpt-4o-mini", "gpt-4o")
    override val needsKey = true
    override val needsInternet = true
    override suspend fun chat(system: String, history: List<Turn>, cfg: AIConfig): String {
        requireKey(cfg, displayName)
        return openAiCompat("https://api.openai.com/v1/chat/completions", cfg.apiKey, system, history, cfg, "max_completion_tokens")
    }
}

object GeminiProvider : AIService {
    override val id = "gemini"
    override val displayName = "Google Gemini"
    override val defaultModel = "gemini-2.5-flash"
    override val suggestedModels = listOf("gemini-2.5-flash", "gemini-2.5-flash-lite", "gemini-2.5-pro")
    override val needsKey = true
    override val needsInternet = true
    override suspend fun chat(system: String, history: List<Turn>, cfg: AIConfig): String {
        requireKey(cfg, displayName)
        val contents = JSONArray()
        history.normalized().forEach {
            contents.put(
                JSONObject().put("role", if (it.role == "assistant") "model" else "user")
                    .put("parts", JSONArray().put(JSONObject().put("text", it.content)))
            )
        }
        val body = JSONObject()
            .put("system_instruction", JSONObject().put("parts", JSONArray().put(JSONObject().put("text", system))))
            .put("contents", contents)
            .put("generationConfig", JSONObject().put("temperature", cfg.temperature.toDouble()).put("maxOutputTokens", cfg.maxTokens))
        val r = Http.postJson(
            "https://generativelanguage.googleapis.com/v1beta/models/${cfg.model}:generateContent",
            mapOf("x-goog-api-key" to cfg.apiKey), body
        )
        val parts = r.optJSONArray("candidates")?.optJSONObject(0)?.optJSONObject("content")?.optJSONArray("parts") ?: emptyReply()
        val sb = StringBuilder()
        for (i in 0 until parts.length()) sb.append(parts.getJSONObject(i).optString("text", ""))
        val text = sb.toString().trim()
        if (text.isEmpty()) emptyReply()
        return text
    }
}

object ClaudeProvider : AIService {
    override val id = "claude"
    override val displayName = "Anthropic Claude"
    override val defaultModel = "claude-haiku-5-5"
    override val suggestedModels = listOf("claude-haiku-5-5", "claude-sonnet-5-5")
    override val needsKey = true
    override val needsInternet = true
    override suspend fun chat(system: String, history: List<Turn>, cfg: AIConfig): String {
        requireKey(cfg, displayName)
        val msgs = JSONArray()
        history.normalized().forEach { msgs.put(JSONObject().put("role", it.role).put("content", it.content)) }
        val body = JSONObject()
            .put("model", cfg.model)
            .put("max_tokens", cfg.maxTokens)
            .put("temperature", cfg.temperature.coerceAtMost(1f).toDouble())
            .put("system", system)
            .put("messages", msgs)
        val r = Http.postJson(
            "https://api.anthropic.com/v1/messages",
            mapOf("x-api-key" to cfg.apiKey, "anthropic-version" to "2023-06-01"), body
        )
        val arr = r.optJSONArray("content") ?: emptyReply()
        val sb = StringBuilder()
        for (i in 0 until arr.length()) {
            val b = arr.getJSONObject(i)
            if (b.optString("type") == "text") sb.append(b.optString("text"))
        }
        val text = sb.toString().trim()
        if (text.isEmpty()) emptyReply()
        return text
    }
}

/** Any OpenAI-compatible server: Ollama / llama.cpp / LM Studio — on this phone (Termux) or your LAN. */
object LocalProvider : AIService {
    override val id = "local"
    override val displayName = "Local server"
    override val defaultModel = "llama3.2:3b"
    override val suggestedModels = listOf("llama3.2:3b", "qwen2.5:3b", "gemma2:2b")
    override val needsKey = false
    override val needsInternet = false
    override suspend fun chat(system: String, history: List<Turn>, cfg: AIConfig): String =
        openAiCompat(cfg.baseUrl.trimEnd('/') + "/chat/completions", cfg.apiKey, system, history, cfg, "max_tokens")
}
