package com.jarvis.ai.ai

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONException
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL

object Http {
    suspend fun postJson(url: String, headers: Map<String, String>, body: JSONObject): JSONObject =
        withContext(Dispatchers.IO) {
            val conn = try {
                URL(url).openConnection() as HttpURLConnection
            } catch (e: Exception) {
                throw AIException(AIException.Kind.OTHER, "That server address doesn't look valid.")
            }
            try {
                conn.requestMethod = "POST"
                conn.connectTimeout = 15_000
                conn.readTimeout = 60_000
                conn.doOutput = true
                conn.setRequestProperty("Content-Type", "application/json")
                headers.forEach { (k, v) -> conn.setRequestProperty(k, v) }
                conn.outputStream.use { it.write(body.toString().toByteArray(Charsets.UTF_8)) }
                val code = conn.responseCode
                val stream = if (code in 200..299) conn.inputStream else conn.errorStream
                val text = stream?.bufferedReader()?.use { it.readText() }.orEmpty()
                when {
                    code in 200..299 -> JSONObject(text)
                    code == 401 || code == 403 -> throw AIException(AIException.Kind.AUTH, "Key rejected")
                    code == 429 -> throw AIException(AIException.Kind.RATE, "Rate limited")
                    code in 500..599 -> throw AIException(AIException.Kind.SERVER, "Server error $code")
                    text.contains("API key", ignoreCase = true) -> throw AIException(AIException.Kind.AUTH, "Key rejected")
                    else -> throw AIException(AIException.Kind.OTHER, detail(text, code))
                }
            } catch (e: AIException) {
                throw e
            } catch (e: JSONException) {
                throw AIException(AIException.Kind.OTHER, "The AI server sent a reply I couldn't read.")
            } catch (e: IOException) {
                throw AIException(AIException.Kind.NETWORK, "Network error")
            } finally {
                conn.disconnect()
            }
        }

    suspend fun getText(url: String): String = withContext(Dispatchers.IO) {
        val conn = URL(url).openConnection() as HttpURLConnection
        try {
            conn.connectTimeout = 8_000
            conn.readTimeout = 10_000
            conn.setRequestProperty("User-Agent", "curl/8.0")
            if (conn.responseCode !in 200..299) throw IOException("HTTP ${conn.responseCode}")
            conn.inputStream.bufferedReader().use { it.readText() }
        } finally {
            conn.disconnect()
        }
    }

    private fun detail(text: String, code: Int): String {
        val msg = try { JSONObject(text).optJSONObject("error")?.optString("message") } catch (e: Exception) { null }
        return "The AI service said: " + (msg?.takeIf { it.isNotBlank() } ?: "error $code").take(200)
    }
}
