package com.jarvis.ai.commands

import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

object AppCommands : CommandGroup {
    override val name = "App commands"
    override val examples = listOf("Open camera", "Open YouTube", "Open Chrome", "Launch Maps")

    override suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult? {
        if (has(t, "take a photo", "take a picture", "take a selfie") || Regex("^(open|start|launch) (the )?camera( app)?$").matches(t)) {
            return if (launch(c.app, Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA))) CommandResult("Opening the camera.")
            else CommandResult("I couldn't open a camera app on this device.", false)
        }
        if (Regex("^(open|start|launch) (the )?youtube( app)?$").matches(t)) {
            val pm = c.app.packageManager
            val app = pm.getLaunchIntentForPackage("com.google.android.youtube")
            if (app != null && launch(c.app, app)) return CommandResult("Opening YouTube.")
            return if (launch(c.app, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com"))))
                CommandResult("YouTube isn't installed, so I opened it in your browser.")
            else CommandResult("I couldn't open YouTube.", false)
        }
        val m = Regex("^(open|launch|start) (the )?(.+?)( app)?$").find(t) ?: return null
        val wanted = m.groupValues[3].trim()
        if (wanted.isEmpty() || wanted.split(" ").size > 3) return null
        val pm = c.app.packageManager
        val main = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val match = pm.queryIntentActivities(main, 0)
            .map { it to it.loadLabel(pm).toString() }
            .filter { it.second.lowercase().contains(wanted) }
            .minByOrNull { it.second.length } ?: return CommandResult("I couldn't find an app called $wanted on this phone.", false)
        val i = pm.getLaunchIntentForPackage(match.first.activityInfo.packageName)
            ?: return CommandResult("I found ${match.second} but can't launch it.", false)
        return if (launch(c.app, i)) CommandResult("Opening ${match.second}.") else CommandResult("I couldn't open ${match.second}.", false)
    }
}
