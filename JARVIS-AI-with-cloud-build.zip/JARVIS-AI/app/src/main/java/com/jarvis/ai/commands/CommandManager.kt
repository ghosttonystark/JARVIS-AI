package com.jarvis.ai.commands

import android.content.ActivityNotFoundException
import android.content.Context
import android.content.Intent
import com.jarvis.ai.memory.MemoryRepository

class CommandContext(
    val app: Context,
    val memory: MemoryRepository,
    val memoryEnabled: Boolean,
    val setAddress: (String) -> Unit
)

data class CommandResult(val reply: String, val success: Boolean = true)

/** Add a new group by implementing this and listing it in [CommandManager.default]. */
interface CommandGroup {
    val name: String
    val examples: List<String>
    /** [t] is lower-cased/trimmed text, [raw] is the original. Return null if this group doesn't handle it. */
    suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult?
}

class CommandManager(private val groups: List<CommandGroup>) {
    suspend fun handle(raw: String, c: CommandContext): CommandResult? {
        val t = raw.lowercase().trim().trimEnd('.', '!', '?', ' ')
        for (g in groups) g.handle(t, raw.trim(), c)?.let { return it }
        return null
    }

    fun help(): List<Pair<String, List<String>>> = groups.map { it.name to it.examples }
    fun summary(): String = groups.joinToString("; ") { it.name + " (" + it.examples.take(2).joinToString(", ") + ")" }

    companion object {
        fun default() = CommandManager(listOf(UtilityCommands, DeviceCommands, SystemCommands, MediaCommands, AppCommands))
    }
}

internal fun has(t: String, vararg words: String) = words.any { t.contains(it) }

/** Starts an activity safely. Returns false if nothing can handle it or Android refuses. */
internal fun launch(c: Context, intent: Intent): Boolean = try {
    intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
    c.startActivity(intent)
    true
} catch (e: ActivityNotFoundException) { false } catch (e: SecurityException) { false }
