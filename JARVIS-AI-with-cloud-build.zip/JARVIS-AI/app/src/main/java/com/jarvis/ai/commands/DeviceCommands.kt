package com.jarvis.ai.commands

import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.media.AudioManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.BatteryManager
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter

object DeviceInfo {
    fun batteryPercent(ctx: Context): Int {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val level = i?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
        val scale = i?.getIntExtra(BatteryManager.EXTRA_SCALE, -1) ?: -1
        return if (level >= 0 && scale > 0) level * 100 / scale else -1
    }

    fun isCharging(ctx: Context): Boolean {
        val i = ctx.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
        val s = i?.getIntExtra(BatteryManager.EXTRA_STATUS, -1) ?: -1
        return s == BatteryManager.BATTERY_STATUS_CHARGING || s == BatteryManager.BATTERY_STATUS_FULL
    }

    fun storageUsed(): Float = try {
        val st = StatFs(Environment.getDataDirectory().path)
        if (st.totalBytes > 0) 1f - st.availableBytes.toFloat() / st.totalBytes else 0f
    } catch (e: Exception) { 0f }

    fun storageText(ctx: Context): String = try {
        val st = StatFs(Environment.getDataDirectory().path)
        "${Formatter.formatFileSize(ctx, st.availableBytes)} free of ${Formatter.formatFileSize(ctx, st.totalBytes)}"
    } catch (e: Exception) { "unknown" }

    fun networkType(ctx: Context): String? {
        val cm = ctx.getSystemService(ConnectivityManager::class.java) ?: return null
        val caps = cm.getNetworkCapabilities(cm.activeNetwork ?: return null) ?: return null
        if (!caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)) return null
        return when {
            caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI) -> "Wi-Fi"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR) -> "mobile data"
            caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET) -> "ethernet"
            else -> "a network"
        }
    }
}

object DeviceCommands : CommandGroup {
    override val name = "Device commands"
    override val examples = listOf("What is my battery?", "How much storage is free?", "Am I online?", "Flashlight on", "Volume up")

    override suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult? {
        val ctx = c.app
        if (has(t, "battery")) {
            val p = DeviceInfo.batteryPercent(ctx)
            if (p < 0) return CommandResult("I couldn't read the battery level.", false)
            return CommandResult("Battery is at $p percent" + if (DeviceInfo.isCharging(ctx)) " and charging." else ".")
        }
        if (has(t, "storage", "free space", "disk space")) return CommandResult("Storage: ${DeviceInfo.storageText(ctx)}.")
        if (has(t, "am i online", "internet connection", "network status", "am i connected")) {
            val n = DeviceInfo.networkType(ctx)
            return CommandResult(if (n != null) "You're online via $n." else "You're offline right now.")
        }
        if (has(t, "flashlight", "torch")) {
            val on = !has(t, " off", "disable", "turn off", "switch off")
            return try {
                val cm = ctx.getSystemService(CameraManager::class.java)
                val id = cm.cameraIdList.firstOrNull { cm.getCameraCharacteristics(it).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true }
                    ?: return CommandResult("This device doesn't have a flashlight.", false)
                cm.setTorchMode(id, on)
                CommandResult(if (on) "Flashlight on." else "Flashlight off.")
            } catch (e: Exception) { CommandResult("Android wouldn't let me control the flashlight.", false) }
        }
        if (has(t, "volume", "mute", "unmute")) {
            val am = ctx.getSystemService(AudioManager::class.java)
            val dir = when {
                has(t, "unmute") -> AudioManager.ADJUST_UNMUTE
                has(t, "mute") -> AudioManager.ADJUST_MUTE
                has(t, "up", "raise", "increase", "louder") -> AudioManager.ADJUST_RAISE
                has(t, "down", "lower", "decrease", "quieter") -> AudioManager.ADJUST_LOWER
                else -> return null
            }
            return try {
                am.adjustStreamVolume(AudioManager.STREAM_MUSIC, dir, AudioManager.FLAG_SHOW_UI)
                CommandResult("Done.")
            } catch (e: SecurityException) { CommandResult("Android blocked the volume change.", false) }
        }
        return null
    }
}
