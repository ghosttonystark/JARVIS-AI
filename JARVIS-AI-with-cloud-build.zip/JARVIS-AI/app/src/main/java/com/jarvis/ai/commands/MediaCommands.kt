package com.jarvis.ai.commands

import android.content.Intent
import android.net.Uri
import android.provider.MediaStore

object MediaCommands : CommandGroup {
    override val name = "Media commands"
    override val examples = listOf("Play lo-fi beats on YouTube", "Search YouTube for cooking pasta", "Record a video", "Open music player")

    override suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult? {
        val yt = Regex("^(?:play|search(?: for)?|find)\\s+(.+?)\\s+(?:on|in)\\s+youtube$").find(t)
            ?: Regex("^(?:search youtube for|youtube search|youtube)\\s+(.+)$").find(t)
        if (yt != null) {
            val q = yt.groupValues[1]
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=" + Uri.encode(q)))
            return if (launch(c.app, i)) CommandResult("Searching YouTube for $q.") else CommandResult("I couldn't open YouTube.", false)
        }
        if (has(t, "record a video", "record video", "start recording")) {
            return if (launch(c.app, Intent(MediaStore.INTENT_ACTION_VIDEO_CAMERA))) CommandResult("Opening the video camera.")
            else CommandResult("I couldn't open a video camera app.", false)
        }
        if (Regex("^(open|play|launch) (the )?(music|music player)$").matches(t)) {
            val i = Intent.makeMainSelectorActivity(Intent.ACTION_MAIN, Intent.CATEGORY_APP_MUSIC)
            return if (launch(c.app, i)) CommandResult("Opening your music app.") else CommandResult("I couldn't find a music app.", false)
        }
        return null
    }
}
