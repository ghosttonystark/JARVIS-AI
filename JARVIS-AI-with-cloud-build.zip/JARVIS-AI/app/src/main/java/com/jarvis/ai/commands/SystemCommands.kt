package com.jarvis.ai.commands

import android.content.Intent
import android.net.Uri
import android.os.Build
import android.provider.Settings as AndroidSettings

/** Protected settings can't be changed silently by apps, so JARVIS opens the right screen instead. */
object SystemCommands : CommandGroup {
    override val name = "System commands"
    override val examples = listOf("Open settings", "Turn on Wi-Fi", "Open Bluetooth settings", "Open location settings")

    private fun open(c: CommandContext, i: Intent, ok: String, fail: String) =
        if (launch(c.app, i)) CommandResult(ok) else CommandResult(fail, false)

    override suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult? {
        if (has(t, "wifi", "wi-fi")) {
            val i = if (Build.VERSION.SDK_INT >= 29) Intent(AndroidSettings.Panel.ACTION_INTERNET_CONNECTIVITY) else Intent(AndroidSettings.ACTION_WIFI_SETTINGS)
            return open(c, i, "Android doesn't let apps switch Wi-Fi directly, so I've opened the connectivity panel for you.", "I couldn't open the Wi-Fi settings.")
        }
        if (has(t, "bluetooth")) return open(c, Intent(AndroidSettings.ACTION_BLUETOOTH_SETTINGS), "Android doesn't let apps toggle Bluetooth directly, so I've opened Bluetooth settings.", "I couldn't open Bluetooth settings.")
        if (has(t, "airplane", "flight mode")) return open(c, Intent(AndroidSettings.ACTION_AIRPLANE_MODE_SETTINGS), "Opening airplane mode settings.", "I couldn't open those settings.")
        if (has(t, "location", "gps")) return open(c, Intent(AndroidSettings.ACTION_LOCATION_SOURCE_SETTINGS), "Opening location settings.", "I couldn't open those settings.")
        if (has(t, "brightness", "display settings")) return open(c, Intent(AndroidSettings.ACTION_DISPLAY_SETTINGS), "Opening display settings.", "I couldn't open those settings.")
        if (has(t, "sound settings")) return open(c, Intent(AndroidSettings.ACTION_SOUND_SETTINGS), "Opening sound settings.", "I couldn't open those settings.")
        if (has(t, "app permission", "jarvis settings", "jarvis permission")) {
            val i = Intent(AndroidSettings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + c.app.packageName))
            return open(c, i, "Opening my app settings.", "I couldn't open my app settings.")
        }
        if (has(t, "settings") && has(t, "open", "show", "go to", "launch")) return open(c, Intent(AndroidSettings.ACTION_SETTINGS), "Opening Android settings.", "I couldn't open settings.")
        return null
    }
}
