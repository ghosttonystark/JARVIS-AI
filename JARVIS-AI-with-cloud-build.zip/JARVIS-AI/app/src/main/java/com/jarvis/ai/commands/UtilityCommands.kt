package com.jarvis.ai.commands

import android.content.Intent
import android.net.Uri
import android.provider.AlarmClock
import com.jarvis.ai.ai.Http
import java.text.DateFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

object UtilityCommands : CommandGroup {
    override val name = "Utility commands"
    override val examples = listOf(
        "What time is it?", "What's the date?", "What's the weather?", "Weather in Paris",
        "Remember that my sister's birthday is June 3", "What do you remember?", "Forget my sister's birthday",
        "Set a timer for 10 minutes", "Search the web for pizza dough", "Call me Tony"
    )

    override suspend fun handle(t: String, raw: String, c: CommandContext): CommandResult? {
        if (has(t, "what time is it", "what's the time", "what is the time", "current time", "tell me the time")) {
            return CommandResult("It's " + DateFormat.getTimeInstance(DateFormat.SHORT).format(Date()) + ".")
        }
        if (has(t, "what's the date", "what is the date", "today's date", "what day is it", "what is today")) {
            return CommandResult("Today is " + SimpleDateFormat("EEEE, d MMMM yyyy", Locale.getDefault()).format(Date()) + ".")
        }
        if (t.startsWith("call me ")) {
            val n = raw.substring(8).trim().trimEnd('.', '!')
            if (n.isNotEmpty() && n.length <= 24) { c.setAddress(n); return CommandResult("Of course. I'll call you $n.") }
        }
        Regex("^(?:please )?(?:remember|note|save to memory)(?: that)?\\s+(.+)$", RegexOption.IGNORE_CASE).find(raw)?.let { m ->
            if (!c.memoryEnabled) return CommandResult("Memory is turned off in Settings, so I haven't saved that.", false)
            return try { c.memory.save(m.groupValues[1]); CommandResult("Got it. I'll remember that.") }
            catch (e: Exception) { CommandResult("I couldn't save that to memory.", false) }
        }
        if (has(t, "what do you remember", "what do you know about me", "show my memory", "show my memories")) {
            if (!c.memoryEnabled) return CommandResult("Memory is turned off in Settings.", false)
            val all = c.memory.all()
            return if (all.isEmpty()) CommandResult("I don't have any saved memories yet.")
            else CommandResult("Here's what you asked me to remember: " + all.take(8).joinToString(". ") { it.content.trimEnd('.') } + ".")
        }
        if (has(t, "forget everything", "clear my memory", "clear memory", "erase my memory")) {
            return CommandResult("To protect your data I only wipe memory from the Memory screen. Open it from the menu and tap Clear all.", false)
        }
        Regex("^(?:please )?forget(?: that| about)?\\s+(.+)$").find(t)?.let { m ->
            val n = c.memory.forget(m.groupValues[1].trim())
            return if (n > 0) CommandResult("Done. I've forgotten $n item" + (if (n > 1) "s." else "."))
            else CommandResult("I couldn't find a saved memory matching that.", false)
        }
        Regex("(?:set|start)? ?(?:a )?timer (?:for )?(\\d+)\\s*(second|sec|minute|min|hour|hr)").find(t)?.let { m ->
            val n = m.groupValues[1].toInt()
            val unit = m.groupValues[2]
            val secs = when { unit.startsWith("h") -> n * 3600; unit.startsWith("m") -> n * 60; else -> n }
            val i = Intent(AlarmClock.ACTION_SET_TIMER).putExtra(AlarmClock.EXTRA_LENGTH, secs).putExtra(AlarmClock.EXTRA_SKIP_UI, true)
            return if (launch(c.app, i)) CommandResult("Timer set for $n ${m.groupValues[2]}${if (n == 1) "" else "s"}.")
            else CommandResult("I couldn't set a timer on this device.", false)
        }
        if (has(t, "weather")) return weather(t, c)
        Regex("^(?:search|google)(?: the web| the internet)? for\\s+(.+)$").find(t)?.let { m ->
            val i = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(m.groupValues[1])))
            return if (launch(c.app, i)) CommandResult("Searching the web for ${m.groupValues[1]}.") else CommandResult("I couldn't open the browser.", false)
        }
        return null
    }

    /** Free wttr.in service: location is estimated from your network address — no location permission used. */
    private suspend fun weather(t: String, c: CommandContext): CommandResult {
        val place = Regex("weather (?:in|for|at)\\s+(.+)$").find(t)?.groupValues?.get(1)?.trim().orEmpty()
        return try {
            val txt = Http.getText("https://wttr.in/" + Uri.encode(place) + "?format=%l:+%C,+%t+(feels+%f),+humidity+%h").trim()
            if (txt.isEmpty() || txt.contains("Unknown location", true)) CommandResult("I couldn't find weather for that place.", false)
            else CommandResult("$txt" + if (place.isEmpty()) " (location estimated from your network)." else ".")
        } catch (e: Exception) {
            val q = if (place.isEmpty()) "weather" else "weather $place"
            launch(c.app, Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(q))))
            CommandResult("I couldn't fetch the weather directly, so I opened a web search for it.", false)
        }
    }
}
