package com.jarvis.ai.database

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

data class ChatMessage(val id: Long, val role: String, val text: String, val time: Long)
data class MemoryItem(val id: Long, val content: String, val time: Long)
data class ConvoSummary(val id: Long, val title: String, val time: Long, val count: Int)

/** Plain SQLite (no Room/KSP) — keeps the Termux build light and fast. */
class JarvisDb(context: Context) : SQLiteOpenHelper(context, "jarvis.db", null, 1) {

    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, convo INTEGER NOT NULL, role TEXT NOT NULL, text TEXT NOT NULL, time INTEGER NOT NULL)")
        db.execSQL("CREATE INDEX idx_messages_convo ON messages(convo)")
        db.execSQL("CREATE TABLE memories(id INTEGER PRIMARY KEY AUTOINCREMENT, content TEXT NOT NULL, time INTEGER NOT NULL)")
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {}

    // ---- messages ----
    fun addMessage(convo: Long, role: String, text: String, time: Long): Long {
        val v = ContentValues().apply { put("convo", convo); put("role", role); put("text", text); put("time", time) }
        return writableDatabase.insertOrThrow("messages", null, v)
    }

    fun messages(convo: Long): List<ChatMessage> =
        readableDatabase.rawQuery("SELECT id, role, text, time FROM messages WHERE convo=? ORDER BY id", arrayOf(convo.toString())).use { c ->
            buildList { while (c.moveToNext()) add(ChatMessage(c.getLong(0), c.getString(1), c.getString(2), c.getLong(3))) }
        }

    fun latestConvo(): Long? =
        readableDatabase.rawQuery("SELECT MAX(convo) FROM messages", null).use { c ->
            if (c.moveToFirst() && !c.isNull(0)) c.getLong(0) else null
        }

    fun conversations(): List<ConvoSummary> =
        readableDatabase.rawQuery(
            "SELECT convo, MIN(time), COUNT(*), (SELECT text FROM messages m2 WHERE m2.convo = m.convo AND m2.role='user' ORDER BY id LIMIT 1) " +
                "FROM messages m GROUP BY convo ORDER BY convo DESC", null
        ).use { c ->
            buildList { while (c.moveToNext()) add(ConvoSummary(c.getLong(0), c.getString(3) ?: "(no title)", c.getLong(1), c.getInt(2))) }
        }

    fun deleteMessage(id: Long) { writableDatabase.delete("messages", "id=?", arrayOf(id.toString())) }
    fun deleteConvo(convo: Long) { writableDatabase.delete("messages", "convo=?", arrayOf(convo.toString())) }
    fun clearMessages() { writableDatabase.delete("messages", null, null) }

    // ---- memories ----
    fun addMemory(content: String, time: Long): Long {
        val v = ContentValues().apply { put("content", content); put("time", time) }
        return writableDatabase.insertOrThrow("memories", null, v)
    }

    fun memories(query: String? = null): List<MemoryItem> {
        val q = query?.trim().orEmpty()
        val sql = if (q.isEmpty()) "SELECT id, content, time FROM memories ORDER BY id DESC"
        else "SELECT id, content, time FROM memories WHERE content LIKE ? ORDER BY id DESC"
        val args = if (q.isEmpty()) null else arrayOf("%$q%")
        return readableDatabase.rawQuery(sql, args).use { c ->
            buildList { while (c.moveToNext()) add(MemoryItem(c.getLong(0), c.getString(1), c.getLong(2))) }
        }
    }

    fun deleteMemory(id: Long) { writableDatabase.delete("memories", "id=?", arrayOf(id.toString())) }
    fun deleteMemoriesContaining(q: String): Int = writableDatabase.delete("memories", "content LIKE ?", arrayOf("%$q%"))
    fun clearMemories() { writableDatabase.delete("memories", null, null) }
}
