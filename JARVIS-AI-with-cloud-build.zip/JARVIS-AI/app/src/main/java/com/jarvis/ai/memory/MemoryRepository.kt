package com.jarvis.ai.memory

import com.jarvis.ai.database.JarvisDb
import com.jarvis.ai.database.MemoryItem
import java.text.DateFormat
import java.util.Date

/** Only things the user explicitly asks to remember are stored here. */
class MemoryRepository(private val db: JarvisDb) {
    fun save(content: String): Long = db.addMemory(content.trim(), System.currentTimeMillis())
    fun all(): List<MemoryItem> = db.memories()
    fun search(q: String): List<MemoryItem> = db.memories(q)
    fun delete(id: Long) = db.deleteMemory(id)
    fun forget(q: String): Int = db.deleteMemoriesContaining(q)
    fun clear() = db.clearMemories()

    fun exportText(): String {
        val f = DateFormat.getDateTimeInstance(DateFormat.SHORT, DateFormat.SHORT)
        return all().joinToString("\n") { "- ${it.content}  (${f.format(Date(it.time))})" }.ifEmpty { "(no memories)" }
    }
}
