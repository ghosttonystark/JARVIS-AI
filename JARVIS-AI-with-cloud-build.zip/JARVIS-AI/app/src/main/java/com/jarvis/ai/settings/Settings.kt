package com.jarvis.ai.settings

import android.content.Context
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

data class Settings(
    val provider: String = "gemini",
    val model: String = "gemini-2.5-flash",
    val temperature: Float = 0.7f,
    val maxTokens: Int = 1024,
    val localUrl: String = "http://127.0.0.1:11434/v1",
    val voiceEnabled: Boolean = true,
    val speechRate: Float = 1.0f,
    val pitch: Float = 1.1f,
    val voiceName: String = "",
    val language: String = "en-US",
    val memoryEnabled: Boolean = true,
    val neon: Float = 1f,
    val animation: Float = 1f,
    val oled: Boolean = true,
    val address: String = "Sir",
    val onboarded: Boolean = false
)

class SettingsStore(context: Context, val keys: SecureKeyStore) {
    private val p = context.getSharedPreferences("jarvis_settings", Context.MODE_PRIVATE)

    var value by mutableStateOf(load())
        private set

    fun update(change: (Settings) -> Settings) {
        value = change(value)
        save(value)
    }

    private fun load(): Settings {
        val d = Settings()
        return Settings(
            provider = p.getString("provider", d.provider) ?: d.provider,
            model = p.getString("model", d.model) ?: d.model,
            temperature = p.getFloat("temperature", d.temperature),
            maxTokens = p.getInt("maxTokens", d.maxTokens),
            localUrl = p.getString("localUrl", d.localUrl) ?: d.localUrl,
            voiceEnabled = p.getBoolean("voiceEnabled", d.voiceEnabled),
            speechRate = p.getFloat("speechRate", d.speechRate),
            pitch = p.getFloat("pitch", d.pitch),
            voiceName = p.getString("voiceName", d.voiceName) ?: "",
            language = p.getString("language", d.language) ?: d.language,
            memoryEnabled = p.getBoolean("memoryEnabled", d.memoryEnabled),
            neon = p.getFloat("neon", d.neon),
            animation = p.getFloat("animation", d.animation),
            oled = p.getBoolean("oled", d.oled),
            address = p.getString("address", d.address) ?: d.address,
            onboarded = p.getBoolean("onboarded", d.onboarded)
        )
    }

    private fun save(s: Settings) {
        p.edit()
            .putString("provider", s.provider).putString("model", s.model)
            .putFloat("temperature", s.temperature).putInt("maxTokens", s.maxTokens)
            .putString("localUrl", s.localUrl).putBoolean("voiceEnabled", s.voiceEnabled)
            .putFloat("speechRate", s.speechRate).putFloat("pitch", s.pitch)
            .putString("voiceName", s.voiceName).putString("language", s.language)
            .putBoolean("memoryEnabled", s.memoryEnabled).putFloat("neon", s.neon)
            .putFloat("animation", s.animation).putBoolean("oled", s.oled)
            .putString("address", s.address).putBoolean("onboarded", s.onboarded)
            .apply()
    }
}
