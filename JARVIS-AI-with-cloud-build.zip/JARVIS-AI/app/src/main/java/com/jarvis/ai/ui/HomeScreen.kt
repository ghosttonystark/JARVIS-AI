package com.jarvis.ai.ui

import android.content.Context
import android.content.Intent
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import com.jarvis.ai.commands.DeviceInfo
import com.jarvis.ai.database.ChatMessage
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

fun statusLabel(st: CoreState) = when (st) {
    CoreState.IDLE -> "ONLINE"; CoreState.LISTENING -> "LISTENING"; CoreState.THINKING -> "THINKING"
    CoreState.SPEAKING -> "SPEAKING"; CoreState.ERROR -> "ERROR"; CoreState.OFFLINE -> "OFFLINE"
}

fun shareText(ctx: Context, text: String, title: String) {
    val i = Intent(Intent.ACTION_SEND).setType("text/plain").putExtra(Intent.EXTRA_TEXT, text)
    ctx.startActivity(Intent.createChooser(i, title).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
}

private val QUICK = listOf(
    "Open Camera" to "open camera", "Open YouTube" to "open youtube", "Weather" to "weather",
    "Battery" to "what is my battery", "Time" to "what time is it", "Settings" to "open settings"
)

@Composable
fun HomeScreen(vm: JarvisViewModel, onMenu: () -> Unit, onMic: () -> Unit) {
    val s = vm.settings.value
    val ctx = LocalContext.current
    var input by remember { mutableStateOf("") }
    val listState = rememberLazyListState()
    val state = vm.shownState
    val thinking = vm.coreState == CoreState.THINKING
    val imeOpen = WindowInsets.ime.getBottom(LocalDensity.current) > 0

    var battery by remember { mutableIntStateOf(0) }
    var storage by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) { battery = DeviceInfo.batteryPercent(ctx); storage = DeviceInfo.storageUsed(); delay(30_000) }
    }
    LaunchedEffect(vm.messages.size, thinking) {
        val n = vm.messages.size + if (thinking) 1 else 0
        if (n > 0) listState.animateScrollToItem(n - 1)
    }
    val coreSize by animateDpAsState(if (vm.messages.isEmpty()) 240.dp else 168.dp, tween(400), label = "coreSize")

    Column(Modifier.fillMaxSize().systemBarsPadding().imePadding()) {
        TopBar("J.A.R.V.I.S", onMenu) { StatusChip(state) }

        if (!imeOpen) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 20.dp), horizontalArrangement = Arrangement.SpaceEvenly) {
                MiniGauge(battery.coerceAtLeast(0) / 100f, "POWER")
                MiniGauge(storage, "STORAGE")
                MiniGauge(if (vm.online) 1f else 0f, "LINK")
            }
            Box(Modifier.fillMaxWidth().padding(vertical = 4.dp), contentAlignment = Alignment.Center) {
                Box(Modifier.size(coreSize).cornerBrackets(Hud.Cyan.copy(alpha = 0.7f)).padding(8.dp), contentAlignment = Alignment.Center) {
                    JarvisCore(state, vm.micLevel, s.neon, s.animation, Modifier.fillMaxSize())
                    HudLabel("J.A.R.V.I.S", color = Hud.Text, size = if (vm.messages.isEmpty()) 15.sp else 11.sp, bold = true)
                }
            }
            val line = when {
                vm.coreState == CoreState.LISTENING && vm.partial.isNotBlank() -> "“${vm.partial}”"
                vm.statusLine.isNotBlank() -> vm.statusLine
                else -> statusLabel(state)
            }
            HudLabel(line, Modifier.fillMaxWidth().padding(horizontal = 24.dp), color = if (state == CoreState.ERROR) Hud.Red else Hud.Cyan, size = 12.sp, align = TextAlign.Center)
        }

        Box(Modifier.weight(1f).fillMaxWidth()) {
            if (vm.messages.isEmpty() && !thinking) {
                Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(vm.greeting(), color = Hud.Text, fontSize = 22.sp, fontFamily = Hud.Mono, textAlign = TextAlign.Center)
                    Spacer(Modifier.height(6.dp))
                    HudLabel("TAP THE MIC OR TYPE A MESSAGE", align = TextAlign.Center)
                }
            }
            LazyColumn(Modifier.fillMaxSize(), state = listState, contentPadding = PaddingValues(horizontal = 14.dp, vertical = 8.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                items(vm.messages, key = { it.id }) { m ->
                    val lastAssistant = m.role == "assistant" && m.id == vm.messages.lastOrNull()?.id
                    Bubble(m, lastAssistant, ctx, onRegen = vm::regenerate, onDelete = { vm.deleteMessage(m.id) })
                }
                if (thinking) item { ThinkingBubble() }
            }
        }

        Row(Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp, vertical = 4.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            QUICK.forEach { (label, cmd) -> HudChip(label, false) { vm.send(cmd) } }
        }

        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            val listening = vm.coreState == CoreState.LISTENING
            Box(
                Modifier.size(52.dp).clip(CircleShape)
                    .background(if (listening) Hud.Cyan.copy(alpha = 0.35f) else Hud.Cyan.copy(alpha = 0.12f))
                    .border(1.5.dp, Hud.Cyan, CircleShape).clickable(onClick = onMic),
                contentAlignment = Alignment.Center
            ) { MicIcon(Hud.Cyan, Modifier.size(28.dp)) }

            BasicTextField(
                value = input, onValueChange = { input = it },
                textStyle = TextStyle(color = Hud.Text, fontSize = 15.sp),
                cursorBrush = SolidColor(Hud.Cyan), maxLines = 4,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { vm.send(input); input = "" }),
                modifier = Modifier.weight(1f),
                decorationBox = { inner ->
                    Box(Modifier.fillMaxWidth().heightIn(min = 52.dp).glass(RoundedCornerShape(26.dp)).padding(horizontal = 18.dp, vertical = 14.dp)) {
                        if (input.isEmpty()) HudLabel("MESSAGE JARVIS…", size = 13.sp)
                        inner()
                    }
                }
            )
            Box(
                Modifier.height(52.dp).clip(RoundedCornerShape(26.dp)).background(Hud.Cyan.copy(alpha = 0.2f))
                    .border(1.dp, Hud.Cyan, RoundedCornerShape(26.dp))
                    .clickable { vm.send(input); input = "" }.padding(horizontal = 16.dp),
                contentAlignment = Alignment.Center
            ) { HudLabel("SEND", color = Hud.Cyan, size = 12.sp, bold = true) }
        }
    }
}

@Composable
fun StatusChip(state: CoreState) {
    val c = when (state) { CoreState.ERROR -> Hud.Red; CoreState.OFFLINE -> Hud.Amber; else -> Hud.Cyan }
    Row(Modifier.padding(end = 10.dp).glass(RoundedCornerShape(20.dp), c).padding(horizontal = 12.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(8.dp).clip(CircleShape).background(c))
        Spacer(Modifier.width(7.dp))
        HudLabel(statusLabel(state), color = c, size = 11.sp, bold = true)
    }
}

@Composable
fun Bubble(m: ChatMessage, lastAssistant: Boolean, ctx: Context, onRegen: () -> Unit, onDelete: () -> Unit) {
    val user = m.role == "user"
    val clipboard = LocalClipboardManager.current
    val time = remember(m.time) { SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date(m.time)) }
    Column(Modifier.fillMaxWidth(), horizontalAlignment = if (user) Alignment.End else Alignment.Start) {
        Column(
            Modifier.widthIn(max = 320.dp)
                .glass(RoundedCornerShape(16.dp), if (user) Hud.Blue else Hud.Cyan)
                .padding(horizontal = 14.dp, vertical = 10.dp)
        ) {
            Text(m.text, color = Hud.Text, fontSize = 15.sp, lineHeight = 21.sp)
        }
        Row(Modifier.padding(top = 2.dp), horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
            HudLabel(time, size = 10.sp, modifier = Modifier.padding(end = 6.dp))
            TinyAction("COPY") { clipboard.setText(AnnotatedString(m.text)) }
            if (lastAssistant) TinyAction("REGENERATE", onRegen)
            TinyAction("DELETE", onDelete)
        }
    }
}

@Composable
private fun TinyAction(text: String, onClick: () -> Unit) {
    Box(Modifier.heightIn(min = 32.dp).clickable(onClick = onClick).padding(horizontal = 6.dp), contentAlignment = Alignment.Center) {
        HudLabel(text, color = Hud.Cyan.copy(alpha = 0.8f), size = 10.sp)
    }
}

@Composable
fun ThinkingBubble() {
    val t = rememberInfiniteTransition(label = "dots")
    Row(Modifier.glass(RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 14.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
        for (i in 0..2) {
            val a by t.animateFloat(0.2f, 1f, infiniteRepeatable(tween(600, delayMillis = i * 180), RepeatMode.Reverse), label = "d$i")
            Box(Modifier.size(8.dp).clip(CircleShape).background(Hud.Cyan.copy(alpha = a)))
        }
    }
}
