package com.jarvis.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import com.jarvis.ai.voice.LANGUAGES
import kotlinx.coroutines.launch
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

enum class Screen(val title: String) {
    HOME("Home"), HISTORY("Chat History"), MEMORY("Memory"), VOICE("Voice"),
    COMMANDS("Commands"), SETTINGS("Settings"), ABOUT("About JARVIS")
}

fun hasMic(ctx: android.content.Context) =
    ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

@Composable
fun JarvisRoot(vm: JarvisViewModel) {
    val s = vm.settings.value
    val ctx = LocalContext.current
    Box(Modifier.fillMaxSize()) {
        HudBackground(s.oled)
        if (!s.onboarded) OnboardingScreen(vm) else MainShell(vm)

        vm.banner?.let { msg ->
            Row(
                Modifier.align(Alignment.TopCenter).systemBarsPadding().padding(12.dp).glass(RoundedCornerShape(14.dp), Hud.Red).padding(start = 14.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(msg, Modifier.weight(1f).padding(vertical = 10.dp), color = Hud.Text, fontSize = 13.sp)
                if (msg.contains("permission", true)) Box(Modifier.heightIn(min = 44.dp).clickable {
                    ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }.padding(horizontal = 8.dp), contentAlignment = Alignment.Center) { HudLabel("SETTINGS", color = Hud.Cyan, size = 11.sp, bold = true) }
                Box(Modifier.size(44.dp).clickable { vm.banner = null }, contentAlignment = Alignment.Center) { HudLabel("✕", color = Hud.Text, size = 14.sp) }
            }
        }
    }
}

@Composable
private fun MainShell(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    var screen by rememberSaveable { mutableStateOf(Screen.HOME) }
    val drawer = rememberDrawerState(DrawerValue.Closed)
    val scope = rememberCoroutineScope()

    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) vm.startListening() else vm.showError("Microphone permission was denied. Allow it in app settings to talk to me.")
    }
    val onMic = {
        when {
            vm.coreState == CoreState.LISTENING -> vm.stopListening()
            vm.coreState == CoreState.SPEAKING -> vm.stopSpeaking()
            hasMic(ctx) -> vm.startListening()
            else -> micLauncher.launch(Manifest.permission.RECORD_AUDIO)
        }
    }
    val openMenu: () -> Unit = { scope.launch { drawer.open() } }
    BackHandler(drawer.isOpen || screen != Screen.HOME) {
        if (drawer.isOpen) scope.launch { drawer.close() } else screen = Screen.HOME
    }

    ModalNavigationDrawer(
        drawerState = drawer,
        drawerContent = {
            ModalDrawerSheet(drawerContainerColor = Color(0xF2030A12), drawerContentColor = Hud.Text) {
                Column(Modifier.fillMaxHeight().systemBarsPadding().verticalScroll(rememberScrollState()).padding(16.dp)) {
                    Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) {
                        Box(contentAlignment = Alignment.Center) {
                            JarvisCore(vm.shownState, vm.micLevel, vm.settings.value.neon, vm.settings.value.animation, Modifier.size(130.dp))
                            HudLabel("J.A.R.V.I.S", color = Hud.Text, size = 9.sp, bold = true)
                        }
                    }
                    Spacer(Modifier.height(14.dp))
                    Screen.values().forEach { sc ->
                        val sel = sc == screen
                        Row(
                            Modifier.fillMaxWidth().heightIn(min = 52.dp).padding(vertical = 2.dp).clip(RoundedCornerShape(12.dp))
                                .background(if (sel) Hud.Cyan.copy(alpha = 0.16f) else Color.Transparent)
                                .clickable { screen = sc; scope.launch { drawer.close() } }.padding(horizontal = 16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(Modifier.size(6.dp).clip(CircleShape).background(if (sel) Hud.Cyan else Hud.Dim.copy(alpha = 0.5f)))
                            Spacer(Modifier.width(14.dp))
                            HudLabel(sc.title.uppercase(), color = if (sel) Hud.Cyan else Hud.Text, size = 13.sp, bold = sel)
                        }
                    }
                }
            }
        }
    ) {
        when (screen) {
            Screen.HOME -> HomeScreen(vm, openMenu, onMic)
            Screen.HISTORY -> HistoryScreen(vm, openMenu) { screen = Screen.HOME }
            Screen.MEMORY -> MemoryScreen(vm, openMenu)
            Screen.VOICE -> ScreenFrame("Voice", openMenu) { VoicePanel(vm) }
            Screen.COMMANDS -> CommandsScreen(vm, openMenu)
            Screen.SETTINGS -> SettingsScreen(vm, openMenu)
            Screen.ABOUT -> AboutScreen(vm, openMenu)
        }
    }
}

// ---------------- First run ----------------

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun OnboardingScreen(vm: JarvisViewModel) {
    val ctx = LocalContext.current
    val s = vm.settings.value
    var step by rememberSaveable { mutableStateOf(0) }
    val total = 8
    var micGranted by remember { mutableStateOf(hasMic(ctx)) }
    var notifAsked by remember { mutableStateOf(false) }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { micGranted = it }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { notifAsked = true }

    fun next() {
        step += 1
        if (step == 2 && Build.VERSION.SDK_INT < 33) step = 3
    }

    Column(Modifier.fillMaxSize().systemBarsPadding().padding(20.dp), horizontalAlignment = Alignment.CenterHorizontally) {
        HudLabel("INITIALISING  ${step + 1}/$total", color = Hud.Cyan)
        Spacer(Modifier.height(8.dp))
        Box(contentAlignment = Alignment.Center) {
            JarvisCore(vm.shownState, vm.micLevel, s.neon, s.animation, Modifier.size(if (step == 0) 260.dp else 150.dp))
            HudLabel("J.A.R.V.I.S", color = Hud.Text, size = if (step == 0) 16.sp else 10.sp, bold = true)
        }
        Spacer(Modifier.height(16.dp))
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            when (step) {
                0 -> {
                    Text("Welcome. I'm JARVIS, your personal assistant. Let's get you set up — it takes about a minute.", color = Hud.Text, fontSize = 16.sp)
                }
                1 -> {
                    HudLabel("MICROPHONE", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("To hear you, I need microphone access. Audio is processed by Android's speech recognizer; I never record in the background.", color = Hud.Text, fontSize = 15.sp)
                    HudLabel(if (micGranted) "STATUS: ALLOWED ✓" else "STATUS: NOT ALLOWED", color = if (micGranted) Hud.Cyan else Hud.Amber)
                    if (!micGranted) HudButton("ALLOW MICROPHONE", Modifier.fillMaxWidth()) { micLauncher.launch(Manifest.permission.RECORD_AUDIO) }
                }
                2 -> {
                    HudLabel("NOTIFICATIONS (OPTIONAL)", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("Android 13+ asks before an app may show notifications. I don't need them yet, but allowing them lets timers and reminders alert you later.", color = Hud.Text, fontSize = 15.sp)
                    if (!notifAsked && Build.VERSION.SDK_INT >= 33) HudButton("ALLOW NOTIFICATIONS", Modifier.fillMaxWidth()) { notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) }
                    else HudLabel("DONE ✓", color = Hud.Cyan)
                }
                3 -> {
                    HudLabel("AI BRAIN", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("I think using an AI provider you choose. Create an API key on the provider's website, paste it here, and it's stored encrypted on this phone. You can skip this and add it later in Settings — until then I can only run device commands.", color = Hud.Text, fontSize = 14.sp)
                    AiPanel(vm)
                }
                4 -> {
                    HudLabel("LANGUAGE", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("Choose the language for listening and speaking. Availability depends on the engines installed on your phone.", color = Hud.Text, fontSize = 14.sp)
                    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        LANGUAGES.forEach { (tag, name) -> HudChip(name, s.language == tag) { vm.settings.update { it.copy(language = tag, voiceName = "") } } }
                    }
                }
                5 -> {
                    HudLabel("VOICE", color = Hud.Cyan, size = 13.sp, bold = true)
                    VoicePanel(vm, showLanguage = false)
                }
                6 -> {
                    HudLabel("TEST MICROPHONE", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("Tap the button and say something.", color = Hud.Text, fontSize = 15.sp)
                    HudButton(if (vm.coreState == CoreState.LISTENING) "LISTENING… TAP TO STOP" else "TEST MICROPHONE", Modifier.fillMaxWidth()) {
                        when {
                            !micGranted -> micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            vm.coreState == CoreState.LISTENING -> vm.stopListening()
                            else -> vm.startListening(autoSend = false)
                        }
                    }
                    if (vm.partial.isNotBlank()) HudLabel("“${vm.partial}”", color = Hud.Text, size = 13.sp)
                    if (vm.heard.isNotBlank()) HudLabel("I HEARD: ${vm.heard}", color = Hud.Cyan, size = 13.sp)
                }
                else -> {
                    HudLabel("TEST MY VOICE", color = Hud.Cyan, size = 13.sp, bold = true)
                    Text("Let me say hello.", color = Hud.Text, fontSize = 15.sp)
                    HudButton("SPEAK", Modifier.fillMaxWidth()) { vm.testVoice() }
                }
            }
        }
        Row(Modifier.fillMaxWidth().padding(top = 10.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            if (step > 0) HudButton("BACK", Modifier.weight(1f)) { step = if (step == 3 && Build.VERSION.SDK_INT < 33) 1 else step - 1 }
            if (step < total - 1) HudButton(if (step == 0) "BEGIN" else "NEXT", Modifier.weight(1f)) { vm.stopListening(); next() }
            else HudButton("OPEN HOME", Modifier.weight(1f)) { vm.stopSpeaking(); vm.settings.update { it.copy(onboarded = true) } }
        }
    }
}
