package com.jarvis.ai.ui

import android.app.Application
import android.net.ConnectivityManager
import android.net.Network
import android.net.NetworkCapabilities
import android.os.Handler
import android.os.Looper
import android.speech.tts.Voice
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.jarvis.ai.JarvisApp
import com.jarvis.ai.ai.AIConfig
import com.jarvis.ai.ai.AIException
import com.jarvis.ai.ai.AIFactory
import com.jarvis.ai.ai.AIService
import com.jarvis.ai.ai.JarvisPrompt
import com.jarvis.ai.ai.Turn
import com.jarvis.ai.commands.CommandContext
import com.jarvis.ai.commands.CommandManager
import com.jarvis.ai.commands.CommandResult
import com.jarvis.ai.database.ChatMessage
import com.jarvis.ai.database.ConvoSummary
import com.jarvis.ai.database.MemoryItem
import com.jarvis.ai.settings.Settings
import com.jarvis.ai.settings.SettingsStore
import com.jarvis.ai.voice.SpeechInput
import com.jarvis.ai.voice.VoiceManager
import kotlinx.coroutines.CancellationException
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.util.Calendar
import java.util.Date

class JarvisViewModel(app: Application) : AndroidViewModel(app) {
    private val jarvis = app as JarvisApp
    val settings: SettingsStore get() = jarvis.settings
    private val db = jarvis.db
    private val memoryRepo = jarvis.memory
    private val voice = VoiceManager(app)
    private val speech = SpeechInput(app)
    private val commands = CommandManager.default()
    private val main = Handler(Looper.getMainLooper())
    private val cm: ConnectivityManager = app.getSystemService(ConnectivityManager::class.java)

    val messages = mutableStateListOf<ChatMessage>()
    val memories = mutableStateListOf<MemoryItem>()
    val conversations = mutableStateListOf<ConvoSummary>()

    var coreState by mutableStateOf(CoreState.IDLE)
        private set
    var statusLine by mutableStateOf("")
        private set
    var micLevel by mutableFloatStateOf(0f)
        private set
    var partial by mutableStateOf("")
        private set
    var heard by mutableStateOf("")
        private set
    var online by mutableStateOf(true)
        private set
    var ttsReady by mutableStateOf(false)
        private set
    var banner by mutableStateOf<String?>(null)

    private var convoId = System.currentTimeMillis()
    private var job: Job? = null

    private val netCb = object : ConnectivityManager.NetworkCallback() {
        override fun onAvailable(network: Network) { main.post { online = true } }
        override fun onLost(network: Network) { main.post { online = isOnline() } }
    }

    val shownState: CoreState
        get() = if (coreState == CoreState.IDLE && !online && AIFactory.get(settings.value.provider).needsInternet) CoreState.OFFLINE else coreState

    val commandHelp get() = commands.help()

    init {
        voice.init { ttsReady = it }
        online = isOnline()
        try { cm.registerDefaultNetworkCallback(netCb) } catch (e: Exception) { /* ignore */ }
        try {
            val last = db.latestConvo()
            if (last != null) { convoId = last; messages.addAll(db.messages(last)) }
        } catch (e: Exception) { banner = "I couldn't load your chat history." }
        refreshMemories()
        refreshConversations()
    }

    private fun isOnline(): Boolean =
        cm.activeNetwork?.let { cm.getNetworkCapabilities(it)?.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET) } == true

    private fun setCore(s: CoreState, line: String = "") { coreState = s; statusLine = line }

    fun greeting(): String {
        val h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY)
        val g = when (h) { in 5..11 -> "Good morning"; in 12..16 -> "Good afternoon"; else -> "Good evening" }
        return "$g, ${settings.value.address}."
    }

    // ---------------- chat ----------------

    private fun add(role: String, text: String): ChatMessage {
        val now = System.currentTimeMillis()
        val id = try { db.addMessage(convoId, role, text, now) } catch (e: Exception) { banner = "I couldn't save that to history."; -now }
        val m = ChatMessage(id, role, text, now)
        messages.add(m)
        return m
    }

    fun send(text: String, fromVoice: Boolean = false) {
        val t = text.trim()
        if (t.isEmpty()) return
        voice.stop(); speech.stop(); micLevel = 0f; partial = ""
        add("user", t)
        job?.cancel()
        job = viewModelScope.launch {
            setCore(CoreState.THINKING, if (fromVoice) "PROCESSING..." else "JARVIS IS THINKING...")
            if (fromVoice) { delay(400); statusLine = "JARVIS IS THINKING..." }
            val cr: CommandResult? = try { commands.handle(t, cmdContext()) }
            catch (e: CancellationException) { throw e }
            catch (e: Exception) { CommandResult("That command failed: ${e.message}", false) }
            if (cr != null) {
                refreshMemories()
                finish(cr.reply, error = !cr.success)
            } else askAI()
        }
    }

    private suspend fun askAI() {
        val s = settings.value
        val svc = AIFactory.get(s.provider)
        if (!online && svc.needsInternet) { finish("I'm offline right now, so I can't reach ${svc.displayName}. Local commands like time, battery and opening apps still work.", true); return }
        val memories = if (s.memoryEnabled) try { memoryRepo.all().take(30).map { it.content } } catch (e: Exception) { emptyList() } else emptyList()
        val system = JarvisPrompt.build(
            s.address, s.language, memories,
            DateFormat.getDateTimeInstance(DateFormat.FULL, DateFormat.SHORT).format(Date()), commands.summary()
        )
        val history = messages.takeLast(24).map { Turn(it.role, it.text) }
        try {
            finish(svc.chat(system, history, buildConfig(s, svc)), false)
        } catch (e: CancellationException) { throw e }
        catch (e: AIException) { finish(friendly(e, svc), true) }
        catch (e: Exception) { finish("Something unexpected went wrong: ${e.message}", true) }
    }

    private fun buildConfig(s: Settings, svc: AIService) = AIConfig(
        apiKey = jarvis.keys.get(svc.id), model = s.model.ifBlank { svc.defaultModel },
        temperature = s.temperature, maxTokens = s.maxTokens, baseUrl = s.localUrl
    )

    private fun friendly(e: AIException, svc: AIService): String = when (e.kind) {
        AIException.Kind.NO_KEY -> "I need an API key for ${svc.displayName} first. Open Settings, then AI, and add one."
        AIException.Kind.AUTH -> "${svc.displayName} rejected the API key. Please check it in Settings."
        AIException.Kind.RATE -> "The AI service is rate-limiting me. Please wait a moment and try again."
        AIException.Kind.SERVER -> "The AI service is having trouble right now. Please try again shortly."
        AIException.Kind.NETWORK -> if (svc.id == "local") "I can't reach your local AI server at ${settings.value.localUrl}. Is it running?"
        else if (!isOnline()) "I'm offline right now. Check your connection and try again." else "I couldn't reach ${svc.displayName}. Please try again."
        AIException.Kind.OTHER -> e.message ?: "Something went wrong."
    }

    private fun finish(text: String, error: Boolean) {
        add("assistant", text)
        if (error) {
            setCore(CoreState.ERROR, "ERROR")
            viewModelScope.launch { delay(2200); if (coreState == CoreState.ERROR) setCore(CoreState.IDLE) }
        } else speakOut(text)
    }

    private fun speakOut(text: String, force: Boolean = false) {
        if (!force && !settings.value.voiceEnabled) { setCore(CoreState.IDLE); return }
        setCore(CoreState.SPEAKING, "SPEAKING...")
        voice.speak(text, settings.value, {}, { err -> if (err != null) banner = err; setCore(CoreState.IDLE) })
    }

    fun testVoice() = speakOut("Hello. I am Jarvis, your personal assistant. Voice systems are online.", force = true)
    fun stopSpeaking() { voice.stop(); if (coreState == CoreState.SPEAKING) setCore(CoreState.IDLE) }

    fun regenerate() {
        val idx = messages.indexOfLast { it.role == "user" }
        if (idx < 0) return
        while (messages.size - 1 > idx) {
            val m = messages.removeAt(messages.lastIndex)
            try { db.deleteMessage(m.id) } catch (e: Exception) { /* ignore */ }
        }
        voice.stop(); job?.cancel()
        job = viewModelScope.launch { setCore(CoreState.THINKING, "JARVIS IS THINKING..."); askAI() }
    }

    fun deleteMessage(id: Long) {
        messages.removeAll { it.id == id }
        try { db.deleteMessage(id) } catch (e: Exception) { banner = "I couldn't delete that message." }
    }

    // ---------------- voice input ----------------

    fun startListening(autoSend: Boolean = true) {
        voice.stop(); job?.cancel()
        heard = ""
        if (!speech.available()) { showError("Speech recognition isn't available on this device."); return }
        setCore(CoreState.LISTENING, "LISTENING...")
        speech.start(
            settings.value.language,
            onLevel = { micLevel = it },
            onPart = { partial = it },
            onText = { text ->
                micLevel = 0f; partial = ""; heard = text
                if (autoSend) send(text, fromVoice = true) else setCore(CoreState.IDLE)
            },
            onFail = { msg -> micLevel = 0f; partial = ""; showError(msg) }
        )
    }

    fun stopListening() { speech.stop(); micLevel = 0f; partial = ""; setCore(CoreState.IDLE) }

    fun showError(msg: String) {
        banner = msg
        setCore(CoreState.ERROR, "ERROR")
        viewModelScope.launch { delay(2200); if (coreState == CoreState.ERROR) setCore(CoreState.IDLE) }
    }

    fun onBackground() { speech.stop(); voice.stop(); micLevel = 0f; partial = ""; if (coreState == CoreState.LISTENING || coreState == CoreState.SPEAKING) setCore(CoreState.IDLE) }

    // ---------------- conversations ----------------

    fun newConversation() { voice.stop(); job?.cancel(); convoId = System.currentTimeMillis(); messages.clear(); setCore(CoreState.IDLE) }

    fun openConversation(id: Long) {
        voice.stop(); job?.cancel(); setCore(CoreState.IDLE)
        convoId = id; messages.clear()
        try { messages.addAll(db.messages(id)) } catch (e: Exception) { banner = "I couldn't open that conversation." }
    }

    fun deleteConversation(id: Long) {
        try { db.deleteConvo(id) } catch (e: Exception) { banner = "I couldn't delete that conversation." }
        if (id == convoId) { messages.clear(); convoId = System.currentTimeMillis() }
        refreshConversations()
    }

    fun clearHistory() {
        try { db.clearMessages() } catch (e: Exception) { banner = "I couldn't clear the history." }
        messages.clear(); convoId = System.currentTimeMillis(); refreshConversations()
    }

    fun refreshConversations() {
        conversations.clear()
        try { conversations.addAll(db.conversations()) } catch (e: Exception) { banner = "I couldn't read the history." }
    }

    // ---------------- memory ----------------

    fun refreshMemories(query: String = "") {
        memories.clear()
        try { memories.addAll(if (query.isBlank()) memoryRepo.all() else memoryRepo.search(query)) } catch (e: Exception) { banner = "I couldn't read memory." }
    }

    fun addMemory(text: String) { if (text.isNotBlank()) try { memoryRepo.save(text) } catch (e: Exception) { banner = "I couldn't save that." }; refreshMemories() }
    fun deleteMemory(id: Long) { try { memoryRepo.delete(id) } catch (e: Exception) { banner = "I couldn't delete that." }; refreshMemories() }
    fun clearMemories() { try { memoryRepo.clear() } catch (e: Exception) { banner = "I couldn't clear memory." }; refreshMemories() }
    fun exportMemories(): String = try { memoryRepo.exportText() } catch (e: Exception) { "" }

    // ---------------- settings helpers ----------------

    fun setProvider(id: String) = settings.update { it.copy(provider = id, model = AIFactory.get(id).defaultModel) }

    fun voices(): List<Voice> = voice.voicesFor(settings.value.language)
    fun isLikelyFemale(v: Voice) = voice.guessFemale(v)

    fun testConnection(onResult: (String) -> Unit) {
        viewModelScope.launch {
            val s = settings.value
            val svc = AIFactory.get(s.provider)
            try {
                svc.chat("Reply with the single word OK.", listOf(Turn("user", "ping")), buildConfig(s, svc).copy(maxTokens = 300))
                onResult("Connection OK ✓")
            } catch (e: CancellationException) { throw e }
            catch (e: AIException) { onResult(friendly(e, svc)) }
            catch (e: Exception) { onResult("Test failed: ${e.message}") }
        }
    }

    private fun cmdContext() = CommandContext(getApplication<Application>(), memoryRepo, settings.value.memoryEnabled) { name ->
        settings.update { it.copy(address = name) }
    }

    override fun onCleared() {
        try { cm.unregisterNetworkCallback(netCb) } catch (e: Exception) { /* ignore */ }
        speech.stop(); voice.shutdown()
    }
}
