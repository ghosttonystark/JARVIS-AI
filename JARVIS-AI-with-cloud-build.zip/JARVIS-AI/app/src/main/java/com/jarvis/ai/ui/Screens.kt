package com.jarvis.ai.ui

import androidx.compose.foundation.text.KeyboardOptions
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

@Composable
fun ScreenFrame(title: String, onMenu: () -> Unit, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxSize().systemBarsPadding()) {
        TopBar(title, onMenu)
        Column(Modifier.weight(1f).verticalScroll(rememberScrollState()).padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp), content = content)
    }
}

@Composable
fun ConfirmDialog(title: String, text: String, confirm: String, onConfirm: () -> Unit, onDismiss: () -> Unit) {
    AlertDialog(
        onDismissRequest = onDismiss, containerColor = Color(0xFF06121E),
        title = { HudLabel(title, color = Hud.Text, size = 14.sp, bold = true) },
        text = { Text(text, color = Hud.Dim, fontSize = 14.sp) },
        confirmButton = { TextButton(onClick = { onConfirm(); onDismiss() }) { HudLabel(confirm, color = Hud.Red, size = 12.sp, bold = true) } },
        dismissButton = { TextButton(onClick = onDismiss) { HudLabel("CANCEL", color = Hud.Cyan, size = 12.sp) } }
    )
}

@Composable
fun HistoryScreen(vm: JarvisViewModel, onMenu: () -> Unit, onOpen: () -> Unit) {
    var confirmAll by remember { mutableStateOf(false) }
    val fmt = remember { SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()) }
    LaunchedEffect(Unit) { vm.refreshConversations() }
    ScreenFrame("Chat History", onMenu) {
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("NEW CHAT", Modifier.weight(1f)) { vm.newConversation(); onOpen() }
            HudButton("CLEAR ALL", Modifier.weight(1f), danger = true) { confirmAll = true }
        }
        if (vm.conversations.isEmpty()) HudLabel("NO CONVERSATIONS YET")
        vm.conversations.forEach { c ->
            Row(Modifier.fillMaxWidth().glass().clickable { vm.openConversation(c.id); onOpen() }.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text(c.title, color = Hud.Text, fontSize = 15.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
                    HudLabel("${fmt.format(Date(c.time))}  ·  ${c.count} msgs", size = 10.sp)
                }
                Box(Modifier.heightIn(min = 44.dp).clickable { vm.deleteConversation(c.id) }.padding(8.dp), contentAlignment = Alignment.Center) { HudLabel("DEL", color = Hud.Red, size = 11.sp) }
            }
        }
    }
    if (confirmAll) ConfirmDialog("Clear all history?", "Every saved conversation will be deleted from this phone. Memory is not affected.", "CLEAR", { vm.clearHistory() }, { confirmAll = false })
}

@Composable
fun MemoryScreen(vm: JarvisViewModel, onMenu: () -> Unit) {
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var newItem by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf(false) }
    ScreenFrame("Memory", onMenu) {
        if (!vm.settings.value.memoryEnabled) HudLabel("MEMORY IS OFF (SETTINGS → MEMORY)", color = Hud.Amber)
        HudLabel("ONLY THINGS YOU ASK ME TO REMEMBER ARE SAVED, ON THIS PHONE. SAY “REMEMBER THAT …” OR ADD ONE BELOW.", size = 10.sp)
        HudField(newItem, { newItem = it }, "ADD A MEMORY")
        HudButton("SAVE", Modifier.fillMaxWidth()) { vm.addMemory(newItem); newItem = "" }
        HudField(query, { query = it; vm.refreshMemories(it) }, "SEARCH MEMORY")
        if (vm.memories.isEmpty()) HudLabel("NOTHING SAVED")
        vm.memories.forEach { m ->
            Row(Modifier.fillMaxWidth().glass().padding(start = 14.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(m.content, Modifier.weight(1f).padding(vertical = 12.dp), color = Hud.Text, fontSize = 15.sp)
                Box(Modifier.size(48.dp).clickable { vm.deleteMemory(m.id) }, contentAlignment = Alignment.Center) { HudLabel("DEL", color = Hud.Red, size = 11.sp) }
            }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("EXPORT", Modifier.weight(1f)) { shareText(ctx, vm.exportMemories(), "Export memory") }
            HudButton("CLEAR ALL", Modifier.weight(1f), danger = true) { confirm = true }
        }
    }
    if (confirm) ConfirmDialog("Clear all memory?", "Everything I've been asked to remember will be permanently deleted.", "CLEAR", { vm.clearMemories() }, { confirm = false })
}

@Composable
fun CommandsScreen(vm: JarvisViewModel, onMenu: () -> Unit) {
    ScreenFrame("Commands", onMenu) {
        HudLabel("SAY OR TYPE THESE. ANYTHING ELSE GOES TO THE AI. NEW COMMANDS: IMPLEMENT CommandGroup.", size = 10.sp)
        vm.commandHelp.forEach { (group, examples) ->
            Column(Modifier.fillMaxWidth().glass().cornerBrackets().padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                HudLabel(group.uppercase(), color = Hud.Cyan, size = 12.sp, bold = true)
                examples.forEach { Text("›  $it", color = Hud.Text, fontSize = 14.sp) }
            }
        }
    }
}

@Composable
fun AboutScreen(vm: JarvisViewModel, onMenu: () -> Unit) {
    ScreenFrame("About JARVIS", onMenu) {
        Box(Modifier.fillMaxWidth(), contentAlignment = Alignment.Center) { HudGlobe(Modifier.size(180.dp), vm.settings.value.animation) }
        HudLabel("J.A.R.V.I.S  ·  v1.0", Modifier.fillMaxWidth(), color = Hud.Text, size = 14.sp, bold = true, align = TextAlign.Center)
        Column(Modifier.fillMaxWidth().glass().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("A voice-first personal assistant. Speech and voice use Android's own engines; thinking is done by the AI provider you choose in Settings.", color = Hud.Text, fontSize = 14.sp)
            Text("What it can't do: it never changes protected settings silently, never runs shell commands from AI replies, and has no access to your contacts, messages or files.", color = Hud.Dim, fontSize = 14.sp)
            Text("Privacy: API keys are encrypted with the Android Keystore. Chat history and memory stay on this phone. Your messages are sent only to the AI provider you select (or your own local server).", color = Hud.Dim, fontSize = 14.sp)
        }
    }
}
