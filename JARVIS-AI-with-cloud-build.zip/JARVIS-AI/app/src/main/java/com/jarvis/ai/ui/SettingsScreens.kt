package com.jarvis.ai.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.core.content.ContextCompat
import com.jarvis.ai.ai.AIFactory
import com.jarvis.ai.voice.LANGUAGES
import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*

@Composable
fun SectionCard(title: String, content: @Composable ColumnScope.() -> Unit) {
    Column(Modifier.fillMaxWidth().glass().cornerBrackets().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        HudLabel(title, color = Hud.Cyan, size = 12.sp, bold = true)
        content()
    }
}

@Composable
fun SwitchRow(label: String, checked: Boolean, onChange: (Boolean) -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
        Text(label, Modifier.weight(1f), color = Hud.Text, fontSize = 15.sp)
        Switch(
            checked, onChange,
            colors = SwitchDefaults.colors(checkedThumbColor = Hud.Cyan, checkedTrackColor = Hud.Cyan.copy(alpha = 0.35f), uncheckedThumbColor = Hud.Dim, uncheckedTrackColor = Color.Transparent)
        )
    }
}

@Composable
fun SliderRow(label: String, value: Float, range: ClosedFloatingPointRange<Float>, display: String, onChange: (Float) -> Unit) {
    Column {
        Row { HudLabel(label, Modifier.weight(1f)); HudLabel(display, color = Hud.Text) }
        Slider(value, onChange, valueRange = range, colors = SliderDefaults.colors(thumbColor = Hud.Cyan, activeTrackColor = Hud.Cyan, inactiveTrackColor = Hud.Cyan.copy(alpha = 0.2f)))
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun VoicePanel(vm: JarvisViewModel, showLanguage: Boolean = true) {
    val s = vm.settings.value
    val voices = remember(s.language, vm.ttsReady) { vm.voices() }
    SwitchRow("Voice replies", s.voiceEnabled) { v -> vm.settings.update { it.copy(voiceEnabled = v) } }
    SliderRow("SPEECH SPEED", s.speechRate, 0.5f..2f, "%.2fx".format(s.speechRate)) { v -> vm.settings.update { it.copy(speechRate = v) } }
    SliderRow("VOICE PITCH", s.pitch, 0.5f..2f, "%.2f".format(s.pitch)) { v -> vm.settings.update { it.copy(pitch = v) } }
    if (showLanguage) {
        HudLabel("LANGUAGE (SPEECH + VOICE)")
        FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            LANGUAGES.forEach { (tag, name) -> HudChip(name, s.language == tag) { vm.settings.update { it.copy(language = tag, voiceName = "") } } }
        }
    }
    HudLabel("VOICE — ANDROID DOESN'T LABEL GENDER; “♀” MARKS LIKELY FEMALE VOICES")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        HudChip("AUTO (PREFER ♀)", s.voiceName.isEmpty()) { vm.settings.update { it.copy(voiceName = "") } }
        voices.take(12).forEachIndexed { i, v ->
            HudChip((if (vm.isLikelyFemale(v)) "♀ " else "") + "Voice ${i + 1}", s.voiceName == v.name) { vm.settings.update { it.copy(voiceName = v.name) } }
        }
    }
    if (voices.isEmpty()) HudLabel("NO INSTALLED VOICES FOUND FOR THIS LANGUAGE — USING DEVICE DEFAULT", color = Hud.Amber, size = 10.sp)
    HudButton("TEST VOICE", Modifier.fillMaxWidth()) { vm.testVoice() }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun AiPanel(vm: JarvisViewModel) {
    val s = vm.settings.value
    val svc = AIFactory.get(s.provider)
    var keyInput by remember { mutableStateOf("") }
    var tick by remember { mutableIntStateOf(0) }
    var result by remember { mutableStateOf("") }
    val hasKey = remember(s.provider, tick) { vm.settings.keys.has(s.provider) }

    HudLabel("PROVIDER")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        AIFactory.all.forEach { p -> HudChip(p.displayName, s.provider == p.id) { vm.setProvider(p.id); result = "" } }
    }
    HudField(s.model, { v -> vm.settings.update { it.copy(model = v.trim()) } }, "MODEL")
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
        svc.suggestedModels.forEach { m -> HudChip(m, s.model == m) { vm.settings.update { it.copy(model = m) } } }
    }
    if (svc.id == "local") HudField(s.localUrl, { v -> vm.settings.update { it.copy(localUrl = v.trim()) } }, "SERVER URL (OPENAI-COMPATIBLE, e.g. OLLAMA)")
    if (svc.needsKey || svc.id == "local") {
        HudLabel(if (hasKey) "API KEY: STORED (ENCRYPTED)" else if (svc.needsKey) "API KEY: NOT SET" else "API KEY (OPTIONAL)", color = if (hasKey) Hud.Cyan else Hud.Amber)
        HudField(keyInput, { keyInput = it }, "PASTE API KEY", password = true)
        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            HudButton("SAVE KEY", Modifier.weight(1f), enabled = keyInput.isNotBlank()) {
                try { vm.settings.keys.put(s.provider, keyInput); keyInput = ""; tick++ } catch (e: Exception) { vm.showError("I couldn't store the key securely on this device.") }
            }
            HudButton("REMOVE", Modifier.weight(1f), danger = true, enabled = hasKey) { vm.settings.keys.put(s.provider, ""); tick++ }
        }
    }
    SliderRow("TEMPERATURE", s.temperature, 0f..1f, "%.2f".format(s.temperature)) { v -> vm.settings.update { it.copy(temperature = v) } }
    SliderRow("MAX RESPONSE LENGTH", s.maxTokens.toFloat(), 200f..2000f, "${s.maxTokens} tokens") { v -> vm.settings.update { it.copy(maxTokens = (v / 50).toInt() * 50) } }
    HudButton("TEST CONNECTION", Modifier.fillMaxWidth()) { result = "Testing…"; vm.testConnection { result = it } }
    if (result.isNotEmpty()) HudLabel(result, color = if (result.startsWith("Connection OK")) Hud.Cyan else Hud.Text, size = 12.sp)
}

@Composable
fun SettingsScreen(vm: JarvisViewModel, onMenu: () -> Unit) {
    val ctx = LocalContext.current
    val s = vm.settings.value
    var confirmMem by remember { mutableStateOf(false) }
    var confirmKeys by remember { mutableStateOf(false) }
    val micGranted = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED

    ScreenFrame("Settings", onMenu) {
        SectionCard("AI SETTINGS") { AiPanel(vm) }
        SectionCard("VOICE SETTINGS") { VoicePanel(vm) }
        SectionCard("APPEARANCE") {
            SwitchRow("OLED black background", s.oled) { v -> vm.settings.update { it.copy(oled = v) } }
            SliderRow("NEON INTENSITY", s.neon, 0.3f..1.5f, "%.0f%%".format(s.neon * 100)) { v -> vm.settings.update { it.copy(neon = v) } }
            SliderRow("ANIMATION INTENSITY", s.animation, 0f..1.5f, if (s.animation == 0f) "OFF" else "%.0f%%".format(s.animation * 100)) { v -> vm.settings.update { it.copy(animation = v) } }
            HudField(s.address, { v -> vm.settings.update { it.copy(address = v.take(24)) } }, "ADDRESS ME AS")
        }
        SectionCard("MEMORY") {
            SwitchRow("Enable memory", s.memoryEnabled) { v -> vm.settings.update { it.copy(memoryEnabled = v) } }
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HudButton("EXPORT", Modifier.weight(1f)) { shareText(ctx, vm.exportMemories(), "Export memory") }
                HudButton("CLEAR MEMORY", Modifier.weight(1f), danger = true) { confirmMem = true }
            }
        }
        SectionCard("SECURITY") {
            HudLabel("MICROPHONE: " + if (micGranted) "ALLOWED" else "NOT ALLOWED", color = if (micGranted) Hud.Cyan else Hud.Amber)
            HudButton("MANAGE PERMISSIONS", Modifier.fillMaxWidth()) {
                ctx.startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:" + ctx.packageName)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            }
            Text("API keys are encrypted with the Android Keystore and never shown again after saving.", color = Hud.Dim, fontSize = 13.sp)
            HudButton("DELETE ALL API KEYS", Modifier.fillMaxWidth(), danger = true) { confirmKeys = true }
        }
    }
    if (confirmMem) ConfirmDialog("Clear all memory?", "This permanently deletes everything I've been asked to remember.", "CLEAR", { vm.clearMemories() }, { confirmMem = false })
    if (confirmKeys) ConfirmDialog("Delete all API keys?", "You'll need to enter them again to use an AI provider.", "DELETE", { vm.settings.keys.clearAll() }, { confirmKeys = false })
}
