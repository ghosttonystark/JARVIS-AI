package com.jarvis.ai.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.*
import androidx.compose.foundation.shape.*
import androidx.compose.foundation.text.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.*
import androidx.compose.ui.draw.*
import androidx.compose.ui.geometry.*
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.*
import androidx.compose.ui.platform.*
import androidx.compose.ui.text.*
import androidx.compose.ui.text.font.*
import androidx.compose.ui.text.input.*
import androidx.compose.ui.text.style.*
import androidx.compose.ui.unit.*
import kotlin.math.*

enum class CoreState { IDLE, LISTENING, THINKING, SPEAKING, ERROR, OFFLINE }

object Hud {
    val Cyan = Color(0xFF00E5FF)
    val Blue = Color(0xFF1E90FF)
    val Navy = Color(0xFF031526)
    val Void = Color(0xFF02060C)
    val Text = Color(0xFFD9F6FF)
    val Dim = Color(0xFF7FA9BC)
    val Red = Color(0xFFFF3B5C)
    val Amber = Color(0xFFFFB000)
    val Mono = FontFamily.Monospace
}

private fun Color.a(x: Float) = copy(alpha = x.coerceIn(0f, 1f))

@Composable
fun JarvisTheme(content: @Composable () -> Unit) {
    val scheme = darkColorScheme(
        primary = Hud.Cyan, onPrimary = Color.Black, secondary = Hud.Blue,
        background = Hud.Void, surface = Color(0xFF06121E), onSurface = Hud.Text, onBackground = Hud.Text, error = Hud.Red
    )
    MaterialTheme(colorScheme = scheme) {
        CompositionLocalProvider(LocalContentColor provides Hud.Text, content = content)
    }
}

/** Glassmorphism-style card (translucent gradient + neon hairline border; no blur so it stays fast). */
fun Modifier.glass(shape: Shape = RoundedCornerShape(16.dp), tint: Color = Hud.Cyan): Modifier =
    this.clip(shape)
        .background(Brush.verticalGradient(listOf(tint.a(0.14f), tint.a(0.05f))))
        .border(1.dp, Brush.linearGradient(listOf(tint.a(0.55f), tint.a(0.12f))), shape)

/** HUD corner brackets, like the panels in the reference screens. */
fun Modifier.cornerBrackets(color: Color = Hud.Cyan, len: Dp = 16.dp, width: Dp = 1.5.dp): Modifier = this.drawBehind {
    val l = len.toPx(); val w = width.toPx(); val W = size.width; val H = size.height
    fun seg(x1: Float, y1: Float, x2: Float, y2: Float) = drawLine(color, Offset(x1, y1), Offset(x2, y2), strokeWidth = w)
    seg(0f, 0f, l, 0f); seg(0f, 0f, 0f, l); seg(W, 0f, W - l, 0f); seg(W, 0f, W, l)
    seg(0f, H, l, H); seg(0f, H, 0f, H - l); seg(W, H, W - l, H); seg(W, H, W, H - l)
}

@Composable
fun HudBackground(oled: Boolean) {
    Canvas(Modifier.fillMaxSize()) {
        drawRect(
            if (oled) Brush.verticalGradient(listOf(Color.Black, Color(0xFF010811)))
            else Brush.verticalGradient(listOf(Hud.Void, Hud.Navy, Hud.Void))
        )
        val step = 36.dp.toPx()
        val c = Hud.Cyan.a(0.045f)
        var x = 0f
        while (x < size.width) { drawLine(c, Offset(x, 0f), Offset(x, size.height), 1f); x += step }
        var y = 0f
        while (y < size.height) { drawLine(c, Offset(0f, y), Offset(size.width, y), 1f); y += step }
        val glowC = Offset(size.width / 2f, size.height * 0.3f)
        drawCircle(Brush.radialGradient(listOf(Hud.Cyan.a(0.10f), Color.Transparent), center = glowC, radius = size.width), radius = size.width, center = glowC)
    }
}

@Composable
fun HudLabel(
    text: String, modifier: Modifier = Modifier, color: Color = Hud.Dim, size: TextUnit = 11.sp,
    bold: Boolean = false, align: TextAlign? = null
) {
    Text(
        text, modifier, color = color, fontSize = size, fontFamily = Hud.Mono, letterSpacing = 1.5.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal, textAlign = align
    )
}

@Composable
fun HudButton(text: String, modifier: Modifier = Modifier, danger: Boolean = false, enabled: Boolean = true, onClick: () -> Unit) {
    val c = if (danger) Hud.Red else Hud.Cyan
    Box(
        modifier.heightIn(min = 44.dp).glass(RoundedCornerShape(12.dp), c)
            .clickable(enabled = enabled, onClick = onClick).padding(horizontal = 16.dp),
        contentAlignment = Alignment.Center
    ) { HudLabel(text, color = if (enabled) c else Hud.Dim, size = 12.sp, bold = true, align = TextAlign.Center) }
}

@Composable
fun HudChip(text: String, selected: Boolean, onClick: () -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Box(
        Modifier.heightIn(min = 40.dp).clip(shape)
            .background(if (selected) Hud.Cyan.a(0.28f) else Color.Transparent)
            .border(1.dp, if (selected) Hud.Cyan else Hud.Cyan.a(0.3f), shape)
            .clickable(onClick = onClick).padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center
    ) { HudLabel(text, color = if (selected) Hud.Text else Hud.Dim, size = 12.sp) }
}

@Composable
fun HudField(
    value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier,
    password: Boolean = false, singleLine: Boolean = true
) {
    Column(modifier) {
        HudLabel(label)
        Spacer(Modifier.height(4.dp))
        BasicTextField(
            value = value, onValueChange = onChange, singleLine = singleLine,
            textStyle = TextStyle(color = Hud.Text, fontSize = 15.sp, fontFamily = Hud.Mono),
            cursorBrush = SolidColor(Hud.Cyan),
            visualTransformation = if (password) PasswordVisualTransformation() else VisualTransformation.None,
            modifier = Modifier.fillMaxWidth().heightIn(min = 48.dp).glass(RoundedCornerShape(12.dp)).padding(horizontal = 14.dp, vertical = 13.dp)
        )
    }
}

@Composable
fun MenuIcon(modifier: Modifier = Modifier, color: Color = Hud.Cyan) {
    Canvas(modifier.size(24.dp)) {
        val w = size.width
        for (i in 0..2) drawLine(color, Offset(w * 0.15f, w * (0.27f + i * 0.23f)), Offset(w * (if (i == 1) 0.6f else 0.85f), w * (0.27f + i * 0.23f)), strokeWidth = 2.dp.toPx(), cap = StrokeCap.Round)
    }
}

@Composable
fun MicIcon(color: Color, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width; val h = size.height; val sw = w * 0.07f
        drawRoundRect(color, Offset(w * 0.38f, h * 0.14f), Size(w * 0.24f, h * 0.42f), CornerRadius(w * 0.12f))
        drawArc(color, 0f, 180f, false, Offset(w * 0.28f, h * 0.28f), Size(w * 0.44f, h * 0.4f), style = Stroke(sw))
        drawLine(color, Offset(w * 0.5f, h * 0.68f), Offset(w * 0.5f, h * 0.82f), strokeWidth = sw)
        drawLine(color, Offset(w * 0.37f, h * 0.82f), Offset(w * 0.63f, h * 0.82f), strokeWidth = sw, cap = StrokeCap.Round)
    }
}

@Composable
fun TopBar(title: String, onMenu: () -> Unit, trailing: @Composable () -> Unit = {}) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(48.dp).clip(CircleShape).clickable(onClick = onMenu), contentAlignment = Alignment.Center) { MenuIcon() }
        HudLabel(title.uppercase(), Modifier.weight(1f).padding(start = 4.dp), color = Hud.Text, size = 15.sp, bold = true)
        trailing()
    }
}

// ---------- JARVIS CORE (HUD rings like the reference) ----------

@Composable
fun JarvisCore(state: CoreState, level: Float, neon: Float, animation: Float, modifier: Modifier = Modifier) {
    val speed by animateFloatAsState(
        when (state) {
            CoreState.IDLE -> 0.35f; CoreState.LISTENING -> 1.2f; CoreState.THINKING -> 2.6f
            CoreState.SPEAKING -> 1.0f; CoreState.ERROR -> 0.2f; CoreState.OFFLINE -> 0.06f
        }, tween(600), label = "speed"
    )
    val tint by animateColorAsState(if (state == CoreState.ERROR) Hud.Red else Hud.Cyan, tween(400), label = "tint")
    val lv by animateFloatAsState(level, tween(90), label = "level")
    val dim by animateFloatAsState(if (state == CoreState.OFFLINE) 0.35f else 1f, tween(500), label = "dim")
    var phase by remember { mutableFloatStateOf(0f) }
    val spd by rememberUpdatedState(speed * animation)

    LaunchedEffect(animation > 0f) {
        if (animation > 0f) {
            var last = withFrameNanos { it }
            while (true) {
                val now = withFrameNanos { it }
                phase += (now - last) / 1_000_000_000f * spd
                last = now
            }
        }
    }

    Canvas(modifier.aspectRatio(1f)) {
        val pulse = when (state) {
            CoreState.LISTENING -> 1f + lv * 0.05f
            CoreState.IDLE -> 1f + 0.015f * sin(phase * 3f)
            else -> 1f
        }
        scale(pulse, center) { drawCore(state, phase, lv, tint, (neon * dim)) }
    }
}

private fun DrawScope.arcAt(c: Offset, r: Float, start: Float, sweep: Float, w: Float, col: Color, alpha: Float, glow: Boolean = false, fx: PathEffect? = null) {
    val tl = Offset(c.x - r, c.y - r); val sz = Size(r * 2, r * 2)
    if (glow) {
        drawArc(col.a(alpha * 0.10f), start, sweep, false, tl, sz, style = Stroke(w * 5f))
        drawArc(col.a(alpha * 0.22f), start, sweep, false, tl, sz, style = Stroke(w * 2.6f))
    }
    drawArc(col.a(alpha), start, sweep, false, tl, sz, style = Stroke(w, pathEffect = fx))
}

private fun DrawScope.drawCore(state: CoreState, phase: Float, lv: Float, col: Color, a: Float) {
    val c = center
    val R = size.minDimension / 2f
    val rad = PI.toFloat() / 180f
    val thinking = state == CoreState.THINKING

    // 1. outer hairline + bright rotating segments (outer arcs of the reference)
    arcAt(c, R * 0.98f, 0f, 360f, 1.2f, col, 0.45f * a)
    arcAt(c, R * 0.94f, phase * 20f, 62f, R * 0.025f, col, 0.95f * a, glow = true)
    arcAt(c, R * 0.94f, 180f + phase * 20f, 22f, R * 0.025f, col, 0.95f * a, glow = true)
    arcAt(c, R * 0.90f, -phase * 8f, 140f, 2f, col, 0.6f * a)

    // 2. gauge tick ring
    rotate(phase * 5f, c) {
        val r1 = R * 0.84f
        for (i in 0 until 120) {
            val long = i % 5 == 0
            val r2 = r1 - R * (if (long) 0.05f else 0.025f)
            val ang = i * 3f * rad
            drawLine(
                col.a((if (long) 0.9f else 0.45f) * a),
                Offset(c.x + r1 * cos(ang), c.y + r1 * sin(ang)), Offset(c.x + r2 * cos(ang), c.y + r2 * sin(ang)),
                strokeWidth = if (long) 2f else 1f
            )
        }
    }

    // 3. segmented "box" ring + dotted ring
    rotate(-phase * 10f, c) {
        arcAt(c, R * 0.72f, 0f, 230f, R * 0.045f, col, 0.75f * a, fx = PathEffect.dashPathEffect(floatArrayOf(R * 0.04f, R * 0.028f), 0f))
    }
    arcAt(c, R * 0.66f, 0f, 360f, 2f, col, 0.5f * a, fx = PathEffect.dashPathEffect(floatArrayOf(2f, R * 0.03f), 0f))

    // 4. inner bright ring (two arcs with gaps)
    val inner = if (thinking) -phase * 40f else -phase * 12f
    arcAt(c, R * 0.55f, inner, 170f, R * 0.035f, col, 0.95f * a, glow = true)
    arcAt(c, R * 0.55f, inner + 180f, 170f, R * 0.035f, col, 0.95f * a, glow = true)
    arcAt(c, R * 0.47f, 0f, 360f, 1.5f, col, 0.4f * a)
    drawCircle(Brush.radialGradient(listOf(Hud.Blue.a(0.28f * a), Color.Transparent), center = c, radius = R * 0.46f), R * 0.46f, c)

    // 5. state effects
    when (state) {
        CoreState.LISTENING -> for (k in 0..2) {
            val f = (phase * 0.6f + k / 3f) % 1f
            drawCircle(col.a((1f - f) * (0.3f + 0.7f * lv) * a), R * (0.48f + 0.5f * f), c, style = Stroke(2f))
        }
        CoreState.THINKING -> {
            arcAt(c, R * 0.62f, phase * 120f, 90f, R * 0.02f, col, 0.9f * a, glow = true)
            arcAt(c, R * 0.62f, 180f - phase * 90f, 60f, R * 0.02f, col, 0.7f * a)
        }
        CoreState.SPEAKING -> {
            val path = Path()
            val n = 120
            val amp = R * 0.05f * (0.4f + 0.6f * abs(sin(phase * 2.2f)))
            for (i in 0..n) {
                val ang = i.toFloat() / n * 2f * PI.toFloat()
                val rr = R * 0.62f + amp * sin(ang * 7f + phase * 7f)
                val x = c.x + rr * cos(ang); val y = c.y + rr * sin(ang)
                if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
            }
            path.close()
            drawPath(path, col.a(0.9f * a), style = Stroke(2.5f))
        }
        CoreState.ERROR -> drawCircle(col.a(abs(sin(phase * 4f)) * 0.9f), R * 0.62f, c, style = Stroke(3f))
        else -> {}
    }
}

// ---------- small HUD widgets ----------

@Composable
fun MiniGauge(value: Float, label: String, modifier: Modifier = Modifier) {
    val v = value.coerceIn(0f, 1f)
    Column(modifier, horizontalAlignment = Alignment.CenterHorizontally) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.fillMaxSize()) {
                val pad = 4.dp.toPx(); val sw = 3.dp.toPx()
                val tl = Offset(pad, pad); val sz = Size(size.width - 2 * pad, size.height - 2 * pad)
                drawArc(Hud.Cyan.a(0.15f), 0f, 360f, false, tl, sz, style = Stroke(sw))
                drawArc(Hud.Cyan, -90f, 360f * v, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
                drawArc(Hud.Cyan.a(0.35f), 0f, 360f, false, Offset(pad * 2.2f, pad * 2.2f), Size(size.width - 4.4f * pad, size.height - 4.4f * pad),
                    style = Stroke(1f, pathEffect = PathEffect.dashPathEffect(floatArrayOf(2f, 5f), 0f)))
            }
            HudLabel("${(v * 100).toInt()}", color = Hud.Text, size = 12.sp, bold = true)
        }
        HudLabel(label, size = 9.sp)
    }
}

/** Wireframe rotating globe (inspired by the globe HUD reference). */
@Composable
fun HudGlobe(modifier: Modifier = Modifier, animation: Float = 1f) {
    var phase by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(animation > 0f) {
        if (animation > 0f) {
            var last = withFrameNanos { it }
            while (true) { val now = withFrameNanos { it }; phase += (now - last) / 1_000_000_000f * 0.5f * animation; last = now }
        }
    }
    Canvas(modifier.aspectRatio(1f)) {
        val c = center; val R = size.minDimension / 2f * 0.92f
        val line = Hud.Cyan.a(0.55f)
        drawCircle(Hud.Cyan, R, c, style = Stroke(1.5f))
        for (lat in -60..60 step 30) {
            val y = c.y - R * sin(lat * PI.toFloat() / 180f)
            val rx = R * cos(lat * PI.toFloat() / 180f)
            drawOval(line, Offset(c.x - rx, y - rx * 0.12f), Size(rx * 2, rx * 0.24f), style = Stroke(1f))
        }
        for (k in 0 until 6) {
            val w = abs(cos(phase + k * PI.toFloat() / 6f)) * R
            drawOval(line, Offset(c.x - w, c.y - R), Size(w * 2, R * 2), style = Stroke(1f))
        }
        arcAt(c, R * 1.06f, phase * 40f, 40f, 3f, Hud.Cyan, 0.9f, glow = true)
    }
}
