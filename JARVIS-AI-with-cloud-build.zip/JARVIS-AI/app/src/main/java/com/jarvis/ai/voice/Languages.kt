package com.jarvis.ai.voice

/** BCP-47 tag to display name. Whether it works depends on the speech/TTS engines installed on the phone. */
val LANGUAGES: List<Pair<String, String>> = listOf(
    "en-US" to "English (US)", "en-GB" to "English (UK)", "en-IN" to "English (India)",
    "hi-IN" to "हिन्दी", "bn-IN" to "বাংলা", "ur-PK" to "اردو", "ar-SA" to "العربية",
    "es-ES" to "Español", "fr-FR" to "Français", "de-DE" to "Deutsch", "it-IT" to "Italiano",
    "pt-BR" to "Português", "ru-RU" to "Русский", "tr-TR" to "Türkçe",
    "ja-JP" to "日本語", "ko-KR" to "한국어", "zh-CN" to "中文", "id-ID" to "Indonesia"
)
