package com.jarvis.ai.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer

/** Wraps Android's SpeechRecognizer. Call from the main thread. */
class SpeechInput(private val context: Context) {
    private var rec: SpeechRecognizer? = null
    private val main = Handler(Looper.getMainLooper())

    fun available(): Boolean = SpeechRecognizer.isRecognitionAvailable(context)

    fun start(lang: String, onLevel: (Float) -> Unit, onPart: (String) -> Unit, onText: (String) -> Unit, onFail: (String) -> Unit) {
        stop()
        val r = try { SpeechRecognizer.createSpeechRecognizer(context) } catch (e: Exception) { onFail("Speech recognition isn't available on this device."); return }
        rec = r
        r.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) { onLevel(((rmsdB + 2f) / 12f).coerceIn(0f, 1f)) }
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onEvent(eventType: Int, params: Bundle?) {}
            override fun onError(error: Int) { release(r); onFail(describe(error)) }
            override fun onPartialResults(partialResults: Bundle?) {
                val t = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (t.isNotBlank()) onPart(t)
            }
            override fun onResults(results: Bundle?) {
                val t = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                release(r)
                if (t.isBlank()) onFail(describe(SpeechRecognizer.ERROR_NO_MATCH)) else onText(t)
            }
        })
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, lang)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 1)
        }
        try { r.startListening(i) } catch (e: Exception) { release(r); onFail("Couldn't start the microphone.") }
    }

    fun stop() {
        val r = rec ?: return
        rec = null
        try { r.cancel(); r.destroy() } catch (e: Exception) { /* ignore */ }
    }

    private fun release(r: SpeechRecognizer) {
        main.post {
            try { r.destroy() } catch (e: Exception) { /* ignore */ }
            if (rec === r) rec = null
        }
    }

    private fun describe(code: Int) = when (code) {
        SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "I didn't catch that. Please try again."
        SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "Speech recognition needs an internet connection for this language."
        SpeechRecognizer.ERROR_AUDIO -> "There's a problem with the microphone."
        SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "Microphone permission is missing. Please allow it in app settings."
        SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> "The speech recognizer is busy. Try again in a moment."
        12, 13 -> "This language isn't supported by the speech recognizer on this phone."
        else -> "Speech recognition failed (code $code)."
    }
}
