package com.jarvis.ai.voice

import android.content.Context
import android.os.Handler
import android.os.Looper
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import com.jarvis.ai.settings.Settings
import java.util.Locale

/** Text-to-speech with best-effort female voice selection and graceful fallback. */
class VoiceManager(private val context: Context) {
    private var tts: TextToSpeech? = null
    private var ready = false
    private var token = 0
    private val main = Handler(Looper.getMainLooper())

    fun init(onReady: (Boolean) -> Unit) {
        tts = TextToSpeech(context.applicationContext) { status ->
            ready = status == TextToSpeech.SUCCESS
            main.post { onReady(ready) }
        }
    }

    fun voicesFor(lang: String): List<Voice> {
        val t = tts ?: return emptyList()
        val language = Locale.forLanguageTag(lang).language
        return try {
            t.voices.orEmpty()
                .filter { it.locale.language == language && !it.features.contains(TextToSpeech.Engine.KEY_FEATURE_NOT_INSTALLED) }
                .sortedBy { it.name }
        } catch (e: Exception) { emptyList() }
    }

    /** Android does not expose voice gender. These are heuristics (names / common Google TTS codes). */
    fun guessFemale(v: Voice): Boolean {
        val n = v.name.lowercase()
        return n.contains("female") || Regex("-(iob|iog|tpc|tpf|sfg|ene|enc|hia|hid|hif)-").containsMatchIn(n)
    }

    /** [finished] gets null on success or a friendly error message. */
    fun speak(text: String, s: Settings, started: () -> Unit, finished: (String?) -> Unit) {
        val t = tts
        if (!ready || t == null) { finished("Voice output isn't available on this device."); return }
        val locale = Locale.forLanguageTag(s.language)
        val r = t.setLanguage(locale)
        if (r == TextToSpeech.LANG_MISSING_DATA || r == TextToSpeech.LANG_NOT_SUPPORTED) {
            finished("This phone has no speech voice for ${locale.displayName}. Install it in Android's Text-to-speech settings.")
            return
        }
        val voices = voicesFor(s.language)
        val chosen = voices.firstOrNull { it.name == s.voiceName } ?: voices.firstOrNull { guessFemale(it) }
        if (chosen != null) try { t.voice = chosen } catch (e: Exception) { /* keep default */ }
        t.setSpeechRate(s.speechRate)
        t.setPitch(s.pitch)

        val chunks = chunk(clean(text))
        if (chunks.isEmpty()) { finished(null); return }
        val mine = ++token
        val lastId = "jarvis-${chunks.size - 1}"
        t.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
            override fun onStart(utteranceId: String?) { if (utteranceId == "jarvis-0") main.post { if (mine == token) started() } }
            override fun onDone(utteranceId: String?) { if (utteranceId == lastId) main.post { if (mine == token) finished(null) } }
            @Deprecated("Deprecated in Java")
            override fun onError(utteranceId: String?) { main.post { if (mine == token) finished("Something went wrong while speaking.") } }
            override fun onStop(utteranceId: String?, interrupted: Boolean) { main.post { if (mine == token && interrupted) finished(null) } }
        })
        chunks.forEachIndexed { i, c ->
            t.speak(c, if (i == 0) TextToSpeech.QUEUE_FLUSH else TextToSpeech.QUEUE_ADD, null, "jarvis-$i")
        }
    }

    fun stop() { token++; tts?.stop() }
    fun shutdown() { token++; tts?.shutdown(); tts = null }

    private fun clean(s: String) = s.replace(Regex("https?://\\S+"), "link").replace(Regex("[*_`#>~]"), "").trim()

    private fun chunk(s: String): List<String> {
        if (s.isEmpty()) return emptyList()
        val max = minOf(TextToSpeech.getMaxSpeechInputLength() - 100, 3500)
        if (s.length <= max) return listOf(s)
        val out = mutableListOf<String>()
        var cur = StringBuilder()
        for (sentence in s.split(Regex("(?<=[.!?])\\s+"))) {
            if (cur.isNotEmpty() && cur.length + sentence.length + 1 > max) { out.add(cur.toString()); cur = StringBuilder() }
            cur.append(sentence.take(max)).append(' ')
        }
        if (cur.isNotBlank()) out.add(cur.toString())
        return out
    }
}
